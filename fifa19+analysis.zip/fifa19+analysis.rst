
FIFA 19 ANALYSIS
================

IMPORTING MODULES
~~~~~~~~~~~~~~~~~

.. code:: ipython3

    ### FOR MANUPULATION
    import numpy as np
    import pandas as pd
    
    ### FOR VISUALIZATION
    import seaborn as sns
    import matplotlib.pyplot as plt
    import matplotlib.image as mpimg
    import plotly as py
    import plotly.graph_objs as go
    import seaborn as sns
    from IPython.display import display, HTML, YouTubeVideo
    from collections import Counter as counter
    
    print("Modules are imported")


.. parsed-literal::

    Modules are imported
    

FIFA19 COVER PHOTO
~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    plt.figure(1, figsize = (20, 15))
    img = mpimg.imread("fifa19cover.jpg") 
    plt.imshow(img)
    plt.show()



.. image:: output_4_0.png


LOADING DATASET
~~~~~~~~~~~~~~~

.. code:: ipython3

    df_fifa = pd.read_csv("data.csv")
    df_fifa.head(50)




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Unnamed: 0</th>
          <th>ID</th>
          <th>Name</th>
          <th>Age</th>
          <th>Photo</th>
          <th>Nationality</th>
          <th>Flag</th>
          <th>Overall</th>
          <th>Potential</th>
          <th>Club</th>
          <th>...</th>
          <th>Composure</th>
          <th>Marking</th>
          <th>StandingTackle</th>
          <th>SlidingTackle</th>
          <th>GKDiving</th>
          <th>GKHandling</th>
          <th>GKKicking</th>
          <th>GKPositioning</th>
          <th>GKReflexes</th>
          <th>Release Clause</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>0</td>
          <td>158023</td>
          <td>L. Messi</td>
          <td>31</td>
          <td>https://cdn.sofifa.org/players/4/19/158023.png</td>
          <td>Argentina</td>
          <td>https://cdn.sofifa.org/flags/52.png</td>
          <td>94</td>
          <td>94</td>
          <td>FC Barcelona</td>
          <td>...</td>
          <td>96.0</td>
          <td>33.0</td>
          <td>28.0</td>
          <td>26.0</td>
          <td>6.0</td>
          <td>11.0</td>
          <td>15.0</td>
          <td>14.0</td>
          <td>8.0</td>
          <td>€226.5M</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1</td>
          <td>20801</td>
          <td>Cristiano Ronaldo</td>
          <td>33</td>
          <td>https://cdn.sofifa.org/players/4/19/20801.png</td>
          <td>Portugal</td>
          <td>https://cdn.sofifa.org/flags/38.png</td>
          <td>94</td>
          <td>94</td>
          <td>Juventus</td>
          <td>...</td>
          <td>95.0</td>
          <td>28.0</td>
          <td>31.0</td>
          <td>23.0</td>
          <td>7.0</td>
          <td>11.0</td>
          <td>15.0</td>
          <td>14.0</td>
          <td>11.0</td>
          <td>€127.1M</td>
        </tr>
        <tr>
          <th>2</th>
          <td>2</td>
          <td>190871</td>
          <td>Neymar Jr</td>
          <td>26</td>
          <td>https://cdn.sofifa.org/players/4/19/190871.png</td>
          <td>Brazil</td>
          <td>https://cdn.sofifa.org/flags/54.png</td>
          <td>92</td>
          <td>93</td>
          <td>Paris Saint-Germain</td>
          <td>...</td>
          <td>94.0</td>
          <td>27.0</td>
          <td>24.0</td>
          <td>33.0</td>
          <td>9.0</td>
          <td>9.0</td>
          <td>15.0</td>
          <td>15.0</td>
          <td>11.0</td>
          <td>€228.1M</td>
        </tr>
        <tr>
          <th>3</th>
          <td>3</td>
          <td>193080</td>
          <td>De Gea</td>
          <td>27</td>
          <td>https://cdn.sofifa.org/players/4/19/193080.png</td>
          <td>Spain</td>
          <td>https://cdn.sofifa.org/flags/45.png</td>
          <td>91</td>
          <td>93</td>
          <td>Manchester United</td>
          <td>...</td>
          <td>68.0</td>
          <td>15.0</td>
          <td>21.0</td>
          <td>13.0</td>
          <td>90.0</td>
          <td>85.0</td>
          <td>87.0</td>
          <td>88.0</td>
          <td>94.0</td>
          <td>€138.6M</td>
        </tr>
        <tr>
          <th>4</th>
          <td>4</td>
          <td>192985</td>
          <td>K. De Bruyne</td>
          <td>27</td>
          <td>https://cdn.sofifa.org/players/4/19/192985.png</td>
          <td>Belgium</td>
          <td>https://cdn.sofifa.org/flags/7.png</td>
          <td>91</td>
          <td>92</td>
          <td>Manchester City</td>
          <td>...</td>
          <td>88.0</td>
          <td>68.0</td>
          <td>58.0</td>
          <td>51.0</td>
          <td>15.0</td>
          <td>13.0</td>
          <td>5.0</td>
          <td>10.0</td>
          <td>13.0</td>
          <td>€196.4M</td>
        </tr>
        <tr>
          <th>5</th>
          <td>5</td>
          <td>183277</td>
          <td>E. Hazard</td>
          <td>27</td>
          <td>https://cdn.sofifa.org/players/4/19/183277.png</td>
          <td>Belgium</td>
          <td>https://cdn.sofifa.org/flags/7.png</td>
          <td>91</td>
          <td>91</td>
          <td>Chelsea</td>
          <td>...</td>
          <td>91.0</td>
          <td>34.0</td>
          <td>27.0</td>
          <td>22.0</td>
          <td>11.0</td>
          <td>12.0</td>
          <td>6.0</td>
          <td>8.0</td>
          <td>8.0</td>
          <td>€172.1M</td>
        </tr>
        <tr>
          <th>6</th>
          <td>6</td>
          <td>177003</td>
          <td>L. Modrić</td>
          <td>32</td>
          <td>https://cdn.sofifa.org/players/4/19/177003.png</td>
          <td>Croatia</td>
          <td>https://cdn.sofifa.org/flags/10.png</td>
          <td>91</td>
          <td>91</td>
          <td>Real Madrid</td>
          <td>...</td>
          <td>84.0</td>
          <td>60.0</td>
          <td>76.0</td>
          <td>73.0</td>
          <td>13.0</td>
          <td>9.0</td>
          <td>7.0</td>
          <td>14.0</td>
          <td>9.0</td>
          <td>€137.4M</td>
        </tr>
        <tr>
          <th>7</th>
          <td>7</td>
          <td>176580</td>
          <td>L. Suárez</td>
          <td>31</td>
          <td>https://cdn.sofifa.org/players/4/19/176580.png</td>
          <td>Uruguay</td>
          <td>https://cdn.sofifa.org/flags/60.png</td>
          <td>91</td>
          <td>91</td>
          <td>FC Barcelona</td>
          <td>...</td>
          <td>85.0</td>
          <td>62.0</td>
          <td>45.0</td>
          <td>38.0</td>
          <td>27.0</td>
          <td>25.0</td>
          <td>31.0</td>
          <td>33.0</td>
          <td>37.0</td>
          <td>€164M</td>
        </tr>
        <tr>
          <th>8</th>
          <td>8</td>
          <td>155862</td>
          <td>Sergio Ramos</td>
          <td>32</td>
          <td>https://cdn.sofifa.org/players/4/19/155862.png</td>
          <td>Spain</td>
          <td>https://cdn.sofifa.org/flags/45.png</td>
          <td>91</td>
          <td>91</td>
          <td>Real Madrid</td>
          <td>...</td>
          <td>82.0</td>
          <td>87.0</td>
          <td>92.0</td>
          <td>91.0</td>
          <td>11.0</td>
          <td>8.0</td>
          <td>9.0</td>
          <td>7.0</td>
          <td>11.0</td>
          <td>€104.6M</td>
        </tr>
        <tr>
          <th>9</th>
          <td>9</td>
          <td>200389</td>
          <td>J. Oblak</td>
          <td>25</td>
          <td>https://cdn.sofifa.org/players/4/19/200389.png</td>
          <td>Slovenia</td>
          <td>https://cdn.sofifa.org/flags/44.png</td>
          <td>90</td>
          <td>93</td>
          <td>Atlético Madrid</td>
          <td>...</td>
          <td>70.0</td>
          <td>27.0</td>
          <td>12.0</td>
          <td>18.0</td>
          <td>86.0</td>
          <td>92.0</td>
          <td>78.0</td>
          <td>88.0</td>
          <td>89.0</td>
          <td>€144.5M</td>
        </tr>
        <tr>
          <th>10</th>
          <td>10</td>
          <td>188545</td>
          <td>R. Lewandowski</td>
          <td>29</td>
          <td>https://cdn.sofifa.org/players/4/19/188545.png</td>
          <td>Poland</td>
          <td>https://cdn.sofifa.org/flags/37.png</td>
          <td>90</td>
          <td>90</td>
          <td>FC Bayern München</td>
          <td>...</td>
          <td>86.0</td>
          <td>34.0</td>
          <td>42.0</td>
          <td>19.0</td>
          <td>15.0</td>
          <td>6.0</td>
          <td>12.0</td>
          <td>8.0</td>
          <td>10.0</td>
          <td>€127.1M</td>
        </tr>
        <tr>
          <th>11</th>
          <td>11</td>
          <td>182521</td>
          <td>T. Kroos</td>
          <td>28</td>
          <td>https://cdn.sofifa.org/players/4/19/182521.png</td>
          <td>Germany</td>
          <td>https://cdn.sofifa.org/flags/21.png</td>
          <td>90</td>
          <td>90</td>
          <td>Real Madrid</td>
          <td>...</td>
          <td>85.0</td>
          <td>72.0</td>
          <td>79.0</td>
          <td>69.0</td>
          <td>10.0</td>
          <td>11.0</td>
          <td>13.0</td>
          <td>7.0</td>
          <td>10.0</td>
          <td>€156.8M</td>
        </tr>
        <tr>
          <th>12</th>
          <td>12</td>
          <td>182493</td>
          <td>D. Godín</td>
          <td>32</td>
          <td>https://cdn.sofifa.org/players/4/19/182493.png</td>
          <td>Uruguay</td>
          <td>https://cdn.sofifa.org/flags/60.png</td>
          <td>90</td>
          <td>90</td>
          <td>Atlético Madrid</td>
          <td>...</td>
          <td>82.0</td>
          <td>90.0</td>
          <td>89.0</td>
          <td>89.0</td>
          <td>6.0</td>
          <td>8.0</td>
          <td>15.0</td>
          <td>5.0</td>
          <td>15.0</td>
          <td>€90.2M</td>
        </tr>
        <tr>
          <th>13</th>
          <td>13</td>
          <td>168542</td>
          <td>David Silva</td>
          <td>32</td>
          <td>https://cdn.sofifa.org/players/4/19/168542.png</td>
          <td>Spain</td>
          <td>https://cdn.sofifa.org/flags/45.png</td>
          <td>90</td>
          <td>90</td>
          <td>Manchester City</td>
          <td>...</td>
          <td>93.0</td>
          <td>59.0</td>
          <td>53.0</td>
          <td>29.0</td>
          <td>6.0</td>
          <td>15.0</td>
          <td>7.0</td>
          <td>6.0</td>
          <td>12.0</td>
          <td>€111M</td>
        </tr>
        <tr>
          <th>14</th>
          <td>14</td>
          <td>215914</td>
          <td>N. Kanté</td>
          <td>27</td>
          <td>https://cdn.sofifa.org/players/4/19/215914.png</td>
          <td>France</td>
          <td>https://cdn.sofifa.org/flags/18.png</td>
          <td>89</td>
          <td>90</td>
          <td>Chelsea</td>
          <td>...</td>
          <td>85.0</td>
          <td>90.0</td>
          <td>91.0</td>
          <td>85.0</td>
          <td>15.0</td>
          <td>12.0</td>
          <td>10.0</td>
          <td>7.0</td>
          <td>10.0</td>
          <td>€121.3M</td>
        </tr>
        <tr>
          <th>15</th>
          <td>15</td>
          <td>211110</td>
          <td>P. Dybala</td>
          <td>24</td>
          <td>https://cdn.sofifa.org/players/4/19/211110.png</td>
          <td>Argentina</td>
          <td>https://cdn.sofifa.org/flags/52.png</td>
          <td>89</td>
          <td>94</td>
          <td>Juventus</td>
          <td>...</td>
          <td>84.0</td>
          <td>23.0</td>
          <td>20.0</td>
          <td>20.0</td>
          <td>5.0</td>
          <td>4.0</td>
          <td>4.0</td>
          <td>5.0</td>
          <td>8.0</td>
          <td>€153.5M</td>
        </tr>
        <tr>
          <th>16</th>
          <td>16</td>
          <td>202126</td>
          <td>H. Kane</td>
          <td>24</td>
          <td>https://cdn.sofifa.org/players/4/19/202126.png</td>
          <td>England</td>
          <td>https://cdn.sofifa.org/flags/14.png</td>
          <td>89</td>
          <td>91</td>
          <td>Tottenham Hotspur</td>
          <td>...</td>
          <td>89.0</td>
          <td>56.0</td>
          <td>36.0</td>
          <td>38.0</td>
          <td>8.0</td>
          <td>10.0</td>
          <td>11.0</td>
          <td>14.0</td>
          <td>11.0</td>
          <td>€160.7M</td>
        </tr>
        <tr>
          <th>17</th>
          <td>17</td>
          <td>194765</td>
          <td>A. Griezmann</td>
          <td>27</td>
          <td>https://cdn.sofifa.org/players/4/19/194765.png</td>
          <td>France</td>
          <td>https://cdn.sofifa.org/flags/18.png</td>
          <td>89</td>
          <td>90</td>
          <td>Atlético Madrid</td>
          <td>...</td>
          <td>87.0</td>
          <td>59.0</td>
          <td>47.0</td>
          <td>48.0</td>
          <td>14.0</td>
          <td>8.0</td>
          <td>14.0</td>
          <td>13.0</td>
          <td>14.0</td>
          <td>€165.8M</td>
        </tr>
        <tr>
          <th>18</th>
          <td>18</td>
          <td>192448</td>
          <td>M. ter Stegen</td>
          <td>26</td>
          <td>https://cdn.sofifa.org/players/4/19/192448.png</td>
          <td>Germany</td>
          <td>https://cdn.sofifa.org/flags/21.png</td>
          <td>89</td>
          <td>92</td>
          <td>FC Barcelona</td>
          <td>...</td>
          <td>69.0</td>
          <td>25.0</td>
          <td>13.0</td>
          <td>10.0</td>
          <td>87.0</td>
          <td>85.0</td>
          <td>88.0</td>
          <td>85.0</td>
          <td>90.0</td>
          <td>€123.3M</td>
        </tr>
        <tr>
          <th>19</th>
          <td>19</td>
          <td>192119</td>
          <td>T. Courtois</td>
          <td>26</td>
          <td>https://cdn.sofifa.org/players/4/19/192119.png</td>
          <td>Belgium</td>
          <td>https://cdn.sofifa.org/flags/7.png</td>
          <td>89</td>
          <td>90</td>
          <td>Real Madrid</td>
          <td>...</td>
          <td>66.0</td>
          <td>20.0</td>
          <td>18.0</td>
          <td>16.0</td>
          <td>85.0</td>
          <td>91.0</td>
          <td>72.0</td>
          <td>86.0</td>
          <td>88.0</td>
          <td>€113.7M</td>
        </tr>
        <tr>
          <th>20</th>
          <td>20</td>
          <td>189511</td>
          <td>Sergio Busquets</td>
          <td>29</td>
          <td>https://cdn.sofifa.org/players/4/19/189511.png</td>
          <td>Spain</td>
          <td>https://cdn.sofifa.org/flags/45.png</td>
          <td>89</td>
          <td>89</td>
          <td>FC Barcelona</td>
          <td>...</td>
          <td>90.0</td>
          <td>90.0</td>
          <td>86.0</td>
          <td>80.0</td>
          <td>5.0</td>
          <td>8.0</td>
          <td>13.0</td>
          <td>9.0</td>
          <td>13.0</td>
          <td>€105.6M</td>
        </tr>
        <tr>
          <th>21</th>
          <td>21</td>
          <td>179813</td>
          <td>E. Cavani</td>
          <td>31</td>
          <td>https://cdn.sofifa.org/players/4/19/179813.png</td>
          <td>Uruguay</td>
          <td>https://cdn.sofifa.org/flags/60.png</td>
          <td>89</td>
          <td>89</td>
          <td>Paris Saint-Germain</td>
          <td>...</td>
          <td>82.0</td>
          <td>52.0</td>
          <td>45.0</td>
          <td>39.0</td>
          <td>12.0</td>
          <td>5.0</td>
          <td>13.0</td>
          <td>13.0</td>
          <td>10.0</td>
          <td>€111M</td>
        </tr>
        <tr>
          <th>22</th>
          <td>22</td>
          <td>167495</td>
          <td>M. Neuer</td>
          <td>32</td>
          <td>https://cdn.sofifa.org/players/4/19/167495.png</td>
          <td>Germany</td>
          <td>https://cdn.sofifa.org/flags/21.png</td>
          <td>89</td>
          <td>89</td>
          <td>FC Bayern München</td>
          <td>...</td>
          <td>70.0</td>
          <td>17.0</td>
          <td>10.0</td>
          <td>11.0</td>
          <td>90.0</td>
          <td>86.0</td>
          <td>91.0</td>
          <td>87.0</td>
          <td>87.0</td>
          <td>€62.7M</td>
        </tr>
        <tr>
          <th>23</th>
          <td>23</td>
          <td>153079</td>
          <td>S. Agüero</td>
          <td>30</td>
          <td>https://cdn.sofifa.org/players/4/19/153079.png</td>
          <td>Argentina</td>
          <td>https://cdn.sofifa.org/flags/52.png</td>
          <td>89</td>
          <td>89</td>
          <td>Manchester City</td>
          <td>...</td>
          <td>90.0</td>
          <td>30.0</td>
          <td>20.0</td>
          <td>12.0</td>
          <td>13.0</td>
          <td>15.0</td>
          <td>6.0</td>
          <td>11.0</td>
          <td>14.0</td>
          <td>€119.3M</td>
        </tr>
        <tr>
          <th>24</th>
          <td>24</td>
          <td>138956</td>
          <td>G. Chiellini</td>
          <td>33</td>
          <td>https://cdn.sofifa.org/players/4/19/138956.png</td>
          <td>Italy</td>
          <td>https://cdn.sofifa.org/flags/27.png</td>
          <td>89</td>
          <td>89</td>
          <td>Juventus</td>
          <td>...</td>
          <td>84.0</td>
          <td>93.0</td>
          <td>93.0</td>
          <td>90.0</td>
          <td>3.0</td>
          <td>3.0</td>
          <td>2.0</td>
          <td>4.0</td>
          <td>3.0</td>
          <td>€44.6M</td>
        </tr>
        <tr>
          <th>25</th>
          <td>25</td>
          <td>231747</td>
          <td>K. Mbappé</td>
          <td>19</td>
          <td>https://cdn.sofifa.org/players/4/19/231747.png</td>
          <td>France</td>
          <td>https://cdn.sofifa.org/flags/18.png</td>
          <td>88</td>
          <td>95</td>
          <td>Paris Saint-Germain</td>
          <td>...</td>
          <td>86.0</td>
          <td>34.0</td>
          <td>34.0</td>
          <td>32.0</td>
          <td>13.0</td>
          <td>5.0</td>
          <td>7.0</td>
          <td>11.0</td>
          <td>6.0</td>
          <td>€166.1M</td>
        </tr>
        <tr>
          <th>26</th>
          <td>26</td>
          <td>209331</td>
          <td>M. Salah</td>
          <td>26</td>
          <td>https://cdn.sofifa.org/players/4/19/209331.png</td>
          <td>Egypt</td>
          <td>https://cdn.sofifa.org/flags/111.png</td>
          <td>88</td>
          <td>89</td>
          <td>Liverpool</td>
          <td>...</td>
          <td>91.0</td>
          <td>38.0</td>
          <td>43.0</td>
          <td>41.0</td>
          <td>14.0</td>
          <td>14.0</td>
          <td>9.0</td>
          <td>11.0</td>
          <td>14.0</td>
          <td>€137.3M</td>
        </tr>
        <tr>
          <th>27</th>
          <td>27</td>
          <td>200145</td>
          <td>Casemiro</td>
          <td>26</td>
          <td>https://cdn.sofifa.org/players/4/19/200145.png</td>
          <td>Brazil</td>
          <td>https://cdn.sofifa.org/flags/54.png</td>
          <td>88</td>
          <td>90</td>
          <td>Real Madrid</td>
          <td>...</td>
          <td>84.0</td>
          <td>88.0</td>
          <td>90.0</td>
          <td>87.0</td>
          <td>13.0</td>
          <td>14.0</td>
          <td>16.0</td>
          <td>12.0</td>
          <td>12.0</td>
          <td>€126.4M</td>
        </tr>
        <tr>
          <th>28</th>
          <td>28</td>
          <td>198710</td>
          <td>J. Rodríguez</td>
          <td>26</td>
          <td>https://cdn.sofifa.org/players/4/19/198710.png</td>
          <td>Colombia</td>
          <td>https://cdn.sofifa.org/flags/56.png</td>
          <td>88</td>
          <td>89</td>
          <td>FC Bayern München</td>
          <td>...</td>
          <td>87.0</td>
          <td>52.0</td>
          <td>41.0</td>
          <td>44.0</td>
          <td>15.0</td>
          <td>15.0</td>
          <td>15.0</td>
          <td>5.0</td>
          <td>14.0</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>29</th>
          <td>29</td>
          <td>198219</td>
          <td>L. Insigne</td>
          <td>27</td>
          <td>https://cdn.sofifa.org/players/4/19/198219.png</td>
          <td>Italy</td>
          <td>https://cdn.sofifa.org/flags/27.png</td>
          <td>88</td>
          <td>88</td>
          <td>Napoli</td>
          <td>...</td>
          <td>83.0</td>
          <td>51.0</td>
          <td>24.0</td>
          <td>22.0</td>
          <td>8.0</td>
          <td>4.0</td>
          <td>14.0</td>
          <td>9.0</td>
          <td>10.0</td>
          <td>€105.4M</td>
        </tr>
        <tr>
          <th>30</th>
          <td>30</td>
          <td>197781</td>
          <td>Isco</td>
          <td>26</td>
          <td>https://cdn.sofifa.org/players/4/19/197781.png</td>
          <td>Spain</td>
          <td>https://cdn.sofifa.org/flags/45.png</td>
          <td>88</td>
          <td>91</td>
          <td>Real Madrid</td>
          <td>...</td>
          <td>86.0</td>
          <td>60.0</td>
          <td>64.0</td>
          <td>51.0</td>
          <td>10.0</td>
          <td>8.0</td>
          <td>12.0</td>
          <td>15.0</td>
          <td>6.0</td>
          <td>€156.2M</td>
        </tr>
        <tr>
          <th>31</th>
          <td>31</td>
          <td>190460</td>
          <td>C. Eriksen</td>
          <td>26</td>
          <td>https://cdn.sofifa.org/players/4/19/190460.png</td>
          <td>Denmark</td>
          <td>https://cdn.sofifa.org/flags/13.png</td>
          <td>88</td>
          <td>91</td>
          <td>Tottenham Hotspur</td>
          <td>...</td>
          <td>88.0</td>
          <td>59.0</td>
          <td>57.0</td>
          <td>22.0</td>
          <td>9.0</td>
          <td>14.0</td>
          <td>7.0</td>
          <td>7.0</td>
          <td>6.0</td>
          <td>€141.5M</td>
        </tr>
        <tr>
          <th>32</th>
          <td>32</td>
          <td>189242</td>
          <td>Coutinho</td>
          <td>26</td>
          <td>https://cdn.sofifa.org/players/4/19/189242.png</td>
          <td>Brazil</td>
          <td>https://cdn.sofifa.org/flags/54.png</td>
          <td>88</td>
          <td>89</td>
          <td>FC Barcelona</td>
          <td>...</td>
          <td>85.0</td>
          <td>55.0</td>
          <td>54.0</td>
          <td>47.0</td>
          <td>12.0</td>
          <td>7.0</td>
          <td>9.0</td>
          <td>14.0</td>
          <td>6.0</td>
          <td>€147.7M</td>
        </tr>
        <tr>
          <th>33</th>
          <td>33</td>
          <td>188567</td>
          <td>P. Aubameyang</td>
          <td>29</td>
          <td>https://cdn.sofifa.org/players/4/19/188567.png</td>
          <td>Gabon</td>
          <td>https://cdn.sofifa.org/flags/115.png</td>
          <td>88</td>
          <td>88</td>
          <td>Arsenal</td>
          <td>...</td>
          <td>86.0</td>
          <td>27.0</td>
          <td>25.0</td>
          <td>36.0</td>
          <td>6.0</td>
          <td>9.0</td>
          <td>15.0</td>
          <td>9.0</td>
          <td>9.0</td>
          <td>€112.1M</td>
        </tr>
        <tr>
          <th>34</th>
          <td>34</td>
          <td>178603</td>
          <td>M. Hummels</td>
          <td>29</td>
          <td>https://cdn.sofifa.org/players/4/19/178603.png</td>
          <td>Germany</td>
          <td>https://cdn.sofifa.org/flags/21.png</td>
          <td>88</td>
          <td>88</td>
          <td>FC Bayern München</td>
          <td>...</td>
          <td>91.0</td>
          <td>88.0</td>
          <td>90.0</td>
          <td>88.0</td>
          <td>15.0</td>
          <td>6.0</td>
          <td>10.0</td>
          <td>5.0</td>
          <td>6.0</td>
          <td>€75.9M</td>
        </tr>
        <tr>
          <th>35</th>
          <td>35</td>
          <td>176676</td>
          <td>Marcelo</td>
          <td>30</td>
          <td>https://cdn.sofifa.org/players/4/19/176676.png</td>
          <td>Brazil</td>
          <td>https://cdn.sofifa.org/flags/54.png</td>
          <td>88</td>
          <td>88</td>
          <td>Real Madrid</td>
          <td>...</td>
          <td>86.0</td>
          <td>71.0</td>
          <td>85.0</td>
          <td>86.0</td>
          <td>12.0</td>
          <td>5.0</td>
          <td>5.0</td>
          <td>5.0</td>
          <td>9.0</td>
          <td>€88.2M</td>
        </tr>
        <tr>
          <th>36</th>
          <td>36</td>
          <td>173731</td>
          <td>G. Bale</td>
          <td>28</td>
          <td>https://cdn.sofifa.org/players/4/19/173731.png</td>
          <td>Wales</td>
          <td>https://cdn.sofifa.org/flags/50.png</td>
          <td>88</td>
          <td>88</td>
          <td>Real Madrid</td>
          <td>...</td>
          <td>86.0</td>
          <td>54.0</td>
          <td>55.0</td>
          <td>52.0</td>
          <td>15.0</td>
          <td>15.0</td>
          <td>11.0</td>
          <td>5.0</td>
          <td>6.0</td>
          <td>€123M</td>
        </tr>
        <tr>
          <th>37</th>
          <td>37</td>
          <td>167948</td>
          <td>H. Lloris</td>
          <td>31</td>
          <td>https://cdn.sofifa.org/players/4/19/167948.png</td>
          <td>France</td>
          <td>https://cdn.sofifa.org/flags/18.png</td>
          <td>88</td>
          <td>88</td>
          <td>Tottenham Hotspur</td>
          <td>...</td>
          <td>65.0</td>
          <td>29.0</td>
          <td>10.0</td>
          <td>18.0</td>
          <td>88.0</td>
          <td>84.0</td>
          <td>68.0</td>
          <td>83.0</td>
          <td>92.0</td>
          <td>€66.6M</td>
        </tr>
        <tr>
          <th>38</th>
          <td>38</td>
          <td>167664</td>
          <td>G. Higuaín</td>
          <td>30</td>
          <td>https://cdn.sofifa.org/players/4/19/167664.png</td>
          <td>Argentina</td>
          <td>https://cdn.sofifa.org/flags/52.png</td>
          <td>88</td>
          <td>88</td>
          <td>Milan</td>
          <td>...</td>
          <td>86.0</td>
          <td>35.0</td>
          <td>22.0</td>
          <td>18.0</td>
          <td>5.0</td>
          <td>12.0</td>
          <td>7.0</td>
          <td>5.0</td>
          <td>10.0</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>39</th>
          <td>39</td>
          <td>164240</td>
          <td>Thiago Silva</td>
          <td>33</td>
          <td>https://cdn.sofifa.org/players/4/19/164240.png</td>
          <td>Brazil</td>
          <td>https://cdn.sofifa.org/flags/54.png</td>
          <td>88</td>
          <td>88</td>
          <td>Paris Saint-Germain</td>
          <td>...</td>
          <td>81.0</td>
          <td>88.0</td>
          <td>89.0</td>
          <td>85.0</td>
          <td>9.0</td>
          <td>12.0</td>
          <td>5.0</td>
          <td>9.0</td>
          <td>10.0</td>
          <td>€44.4M</td>
        </tr>
        <tr>
          <th>40</th>
          <td>40</td>
          <td>162835</td>
          <td>S. Handanovič</td>
          <td>33</td>
          <td>https://cdn.sofifa.org/players/4/19/162835.png</td>
          <td>Slovenia</td>
          <td>https://cdn.sofifa.org/flags/44.png</td>
          <td>88</td>
          <td>88</td>
          <td>Inter</td>
          <td>...</td>
          <td>69.0</td>
          <td>25.0</td>
          <td>10.0</td>
          <td>13.0</td>
          <td>87.0</td>
          <td>86.0</td>
          <td>69.0</td>
          <td>89.0</td>
          <td>89.0</td>
          <td>€51M</td>
        </tr>
        <tr>
          <th>41</th>
          <td>41</td>
          <td>1179</td>
          <td>G. Buffon</td>
          <td>40</td>
          <td>https://cdn.sofifa.org/players/4/19/1179.png</td>
          <td>Italy</td>
          <td>https://cdn.sofifa.org/flags/27.png</td>
          <td>88</td>
          <td>88</td>
          <td>Paris Saint-Germain</td>
          <td>...</td>
          <td>70.0</td>
          <td>13.0</td>
          <td>11.0</td>
          <td>11.0</td>
          <td>88.0</td>
          <td>87.0</td>
          <td>74.0</td>
          <td>90.0</td>
          <td>83.0</td>
          <td>€7.4M</td>
        </tr>
        <tr>
          <th>42</th>
          <td>42</td>
          <td>205600</td>
          <td>S. Umtiti</td>
          <td>24</td>
          <td>https://cdn.sofifa.org/players/4/19/205600.png</td>
          <td>France</td>
          <td>https://cdn.sofifa.org/flags/18.png</td>
          <td>87</td>
          <td>92</td>
          <td>FC Barcelona</td>
          <td>...</td>
          <td>82.0</td>
          <td>90.0</td>
          <td>89.0</td>
          <td>86.0</td>
          <td>15.0</td>
          <td>10.0</td>
          <td>14.0</td>
          <td>12.0</td>
          <td>15.0</td>
          <td>€121.1M</td>
        </tr>
        <tr>
          <th>43</th>
          <td>43</td>
          <td>201399</td>
          <td>M. Icardi</td>
          <td>25</td>
          <td>https://cdn.sofifa.org/players/4/19/201399.png</td>
          <td>Argentina</td>
          <td>https://cdn.sofifa.org/flags/52.png</td>
          <td>87</td>
          <td>90</td>
          <td>Inter</td>
          <td>...</td>
          <td>85.0</td>
          <td>45.0</td>
          <td>24.0</td>
          <td>20.0</td>
          <td>13.0</td>
          <td>9.0</td>
          <td>5.0</td>
          <td>7.0</td>
          <td>9.0</td>
          <td>€114.5M</td>
        </tr>
        <tr>
          <th>44</th>
          <td>44</td>
          <td>201024</td>
          <td>K. Koulibaly</td>
          <td>27</td>
          <td>https://cdn.sofifa.org/players/4/19/201024.png</td>
          <td>Senegal</td>
          <td>https://cdn.sofifa.org/flags/136.png</td>
          <td>87</td>
          <td>90</td>
          <td>Napoli</td>
          <td>...</td>
          <td>78.0</td>
          <td>91.0</td>
          <td>88.0</td>
          <td>86.0</td>
          <td>7.0</td>
          <td>11.0</td>
          <td>7.0</td>
          <td>13.0</td>
          <td>5.0</td>
          <td>€90.5M</td>
        </tr>
        <tr>
          <th>45</th>
          <td>45</td>
          <td>195864</td>
          <td>P. Pogba</td>
          <td>25</td>
          <td>https://cdn.sofifa.org/players/4/19/195864.png</td>
          <td>France</td>
          <td>https://cdn.sofifa.org/flags/18.png</td>
          <td>87</td>
          <td>91</td>
          <td>Manchester United</td>
          <td>...</td>
          <td>87.0</td>
          <td>66.0</td>
          <td>70.0</td>
          <td>68.0</td>
          <td>5.0</td>
          <td>6.0</td>
          <td>2.0</td>
          <td>4.0</td>
          <td>3.0</td>
          <td>€123.2M</td>
        </tr>
        <tr>
          <th>46</th>
          <td>46</td>
          <td>193041</td>
          <td>K. Navas</td>
          <td>31</td>
          <td>https://cdn.sofifa.org/players/4/19/193041.png</td>
          <td>Costa Rica</td>
          <td>https://cdn.sofifa.org/flags/72.png</td>
          <td>87</td>
          <td>87</td>
          <td>Real Madrid</td>
          <td>...</td>
          <td>67.0</td>
          <td>28.0</td>
          <td>14.0</td>
          <td>14.0</td>
          <td>90.0</td>
          <td>81.0</td>
          <td>75.0</td>
          <td>82.0</td>
          <td>90.0</td>
          <td>€62.5M</td>
        </tr>
        <tr>
          <th>47</th>
          <td>47</td>
          <td>192505</td>
          <td>R. Lukaku</td>
          <td>25</td>
          <td>https://cdn.sofifa.org/players/4/19/192505.png</td>
          <td>Belgium</td>
          <td>https://cdn.sofifa.org/flags/7.png</td>
          <td>87</td>
          <td>89</td>
          <td>Manchester United</td>
          <td>...</td>
          <td>83.0</td>
          <td>30.0</td>
          <td>30.0</td>
          <td>30.0</td>
          <td>8.0</td>
          <td>15.0</td>
          <td>14.0</td>
          <td>7.0</td>
          <td>10.0</td>
          <td>€120.3M</td>
        </tr>
        <tr>
          <th>48</th>
          <td>48</td>
          <td>192387</td>
          <td>C. Immobile</td>
          <td>28</td>
          <td>https://cdn.sofifa.org/players/4/19/192387.png</td>
          <td>Italy</td>
          <td>https://cdn.sofifa.org/flags/27.png</td>
          <td>87</td>
          <td>87</td>
          <td>Lazio</td>
          <td>...</td>
          <td>81.0</td>
          <td>34.0</td>
          <td>33.0</td>
          <td>32.0</td>
          <td>6.0</td>
          <td>8.0</td>
          <td>15.0</td>
          <td>12.0</td>
          <td>6.0</td>
          <td>€88.4M</td>
        </tr>
        <tr>
          <th>49</th>
          <td>49</td>
          <td>189332</td>
          <td>Jordi Alba</td>
          <td>29</td>
          <td>https://cdn.sofifa.org/players/4/19/189332.png</td>
          <td>Spain</td>
          <td>https://cdn.sofifa.org/flags/45.png</td>
          <td>87</td>
          <td>87</td>
          <td>FC Barcelona</td>
          <td>...</td>
          <td>79.0</td>
          <td>72.0</td>
          <td>84.0</td>
          <td>85.0</td>
          <td>13.0</td>
          <td>15.0</td>
          <td>13.0</td>
          <td>6.0</td>
          <td>13.0</td>
          <td>€77.9M</td>
        </tr>
      </tbody>
    </table>
    <p>50 rows × 89 columns</p>
    </div>



SHAPE OF DATASET(ROW, COLUMNS)

.. code:: ipython3

    df_fifa.shape




.. parsed-literal::

    (18207, 89)



DROPPING UNNECESSARY COLUMNS

.. code:: ipython3

    useless_cols = ["ID", "Unnamed: 0", "Photo", "Flag", "Club Logo", "Special", "Body Type", "Real Face", "Joined", "Loaned From",
                    "Contract Valid Until", "Weight", "LS", "ST", "RS", "LW", "LF", "CF", "RF", "RW", "LAM", "CAM", "RAM", "LM", 
                    "LCM", "CM", "RCM", "RM", "LWB", "LDM", "CDM", "RDM", "RWB", "LB", "LCB", "CB", "RCB", "RB", "Release Clause"]
    df_fifa.drop(useless_cols, axis=1, inplace=True)
    df_fifa.head(10)




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Age</th>
          <th>Nationality</th>
          <th>Overall</th>
          <th>Potential</th>
          <th>Club</th>
          <th>Value</th>
          <th>Wage</th>
          <th>Preferred Foot</th>
          <th>International Reputation</th>
          <th>...</th>
          <th>Penalties</th>
          <th>Composure</th>
          <th>Marking</th>
          <th>StandingTackle</th>
          <th>SlidingTackle</th>
          <th>GKDiving</th>
          <th>GKHandling</th>
          <th>GKKicking</th>
          <th>GKPositioning</th>
          <th>GKReflexes</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>L. Messi</td>
          <td>31</td>
          <td>Argentina</td>
          <td>94</td>
          <td>94</td>
          <td>FC Barcelona</td>
          <td>€110.5M</td>
          <td>€565K</td>
          <td>Left</td>
          <td>5.0</td>
          <td>...</td>
          <td>75.0</td>
          <td>96.0</td>
          <td>33.0</td>
          <td>28.0</td>
          <td>26.0</td>
          <td>6.0</td>
          <td>11.0</td>
          <td>15.0</td>
          <td>14.0</td>
          <td>8.0</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Cristiano Ronaldo</td>
          <td>33</td>
          <td>Portugal</td>
          <td>94</td>
          <td>94</td>
          <td>Juventus</td>
          <td>€77M</td>
          <td>€405K</td>
          <td>Right</td>
          <td>5.0</td>
          <td>...</td>
          <td>85.0</td>
          <td>95.0</td>
          <td>28.0</td>
          <td>31.0</td>
          <td>23.0</td>
          <td>7.0</td>
          <td>11.0</td>
          <td>15.0</td>
          <td>14.0</td>
          <td>11.0</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Neymar Jr</td>
          <td>26</td>
          <td>Brazil</td>
          <td>92</td>
          <td>93</td>
          <td>Paris Saint-Germain</td>
          <td>€118.5M</td>
          <td>€290K</td>
          <td>Right</td>
          <td>5.0</td>
          <td>...</td>
          <td>81.0</td>
          <td>94.0</td>
          <td>27.0</td>
          <td>24.0</td>
          <td>33.0</td>
          <td>9.0</td>
          <td>9.0</td>
          <td>15.0</td>
          <td>15.0</td>
          <td>11.0</td>
        </tr>
        <tr>
          <th>3</th>
          <td>De Gea</td>
          <td>27</td>
          <td>Spain</td>
          <td>91</td>
          <td>93</td>
          <td>Manchester United</td>
          <td>€72M</td>
          <td>€260K</td>
          <td>Right</td>
          <td>4.0</td>
          <td>...</td>
          <td>40.0</td>
          <td>68.0</td>
          <td>15.0</td>
          <td>21.0</td>
          <td>13.0</td>
          <td>90.0</td>
          <td>85.0</td>
          <td>87.0</td>
          <td>88.0</td>
          <td>94.0</td>
        </tr>
        <tr>
          <th>4</th>
          <td>K. De Bruyne</td>
          <td>27</td>
          <td>Belgium</td>
          <td>91</td>
          <td>92</td>
          <td>Manchester City</td>
          <td>€102M</td>
          <td>€355K</td>
          <td>Right</td>
          <td>4.0</td>
          <td>...</td>
          <td>79.0</td>
          <td>88.0</td>
          <td>68.0</td>
          <td>58.0</td>
          <td>51.0</td>
          <td>15.0</td>
          <td>13.0</td>
          <td>5.0</td>
          <td>10.0</td>
          <td>13.0</td>
        </tr>
        <tr>
          <th>5</th>
          <td>E. Hazard</td>
          <td>27</td>
          <td>Belgium</td>
          <td>91</td>
          <td>91</td>
          <td>Chelsea</td>
          <td>€93M</td>
          <td>€340K</td>
          <td>Right</td>
          <td>4.0</td>
          <td>...</td>
          <td>86.0</td>
          <td>91.0</td>
          <td>34.0</td>
          <td>27.0</td>
          <td>22.0</td>
          <td>11.0</td>
          <td>12.0</td>
          <td>6.0</td>
          <td>8.0</td>
          <td>8.0</td>
        </tr>
        <tr>
          <th>6</th>
          <td>L. Modrić</td>
          <td>32</td>
          <td>Croatia</td>
          <td>91</td>
          <td>91</td>
          <td>Real Madrid</td>
          <td>€67M</td>
          <td>€420K</td>
          <td>Right</td>
          <td>4.0</td>
          <td>...</td>
          <td>82.0</td>
          <td>84.0</td>
          <td>60.0</td>
          <td>76.0</td>
          <td>73.0</td>
          <td>13.0</td>
          <td>9.0</td>
          <td>7.0</td>
          <td>14.0</td>
          <td>9.0</td>
        </tr>
        <tr>
          <th>7</th>
          <td>L. Suárez</td>
          <td>31</td>
          <td>Uruguay</td>
          <td>91</td>
          <td>91</td>
          <td>FC Barcelona</td>
          <td>€80M</td>
          <td>€455K</td>
          <td>Right</td>
          <td>5.0</td>
          <td>...</td>
          <td>85.0</td>
          <td>85.0</td>
          <td>62.0</td>
          <td>45.0</td>
          <td>38.0</td>
          <td>27.0</td>
          <td>25.0</td>
          <td>31.0</td>
          <td>33.0</td>
          <td>37.0</td>
        </tr>
        <tr>
          <th>8</th>
          <td>Sergio Ramos</td>
          <td>32</td>
          <td>Spain</td>
          <td>91</td>
          <td>91</td>
          <td>Real Madrid</td>
          <td>€51M</td>
          <td>€380K</td>
          <td>Right</td>
          <td>4.0</td>
          <td>...</td>
          <td>75.0</td>
          <td>82.0</td>
          <td>87.0</td>
          <td>92.0</td>
          <td>91.0</td>
          <td>11.0</td>
          <td>8.0</td>
          <td>9.0</td>
          <td>7.0</td>
          <td>11.0</td>
        </tr>
        <tr>
          <th>9</th>
          <td>J. Oblak</td>
          <td>25</td>
          <td>Slovenia</td>
          <td>90</td>
          <td>93</td>
          <td>Atlético Madrid</td>
          <td>€68M</td>
          <td>€94K</td>
          <td>Right</td>
          <td>3.0</td>
          <td>...</td>
          <td>11.0</td>
          <td>70.0</td>
          <td>27.0</td>
          <td>12.0</td>
          <td>18.0</td>
          <td>86.0</td>
          <td>92.0</td>
          <td>78.0</td>
          <td>88.0</td>
          <td>89.0</td>
        </tr>
      </tbody>
    </table>
    <p>10 rows × 50 columns</p>
    </div>



INFORMATION ON DATASET

.. code:: ipython3

    df_fifa.info()


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 18207 entries, 0 to 18206
    Data columns (total 50 columns):
    Name                        18207 non-null object
    Age                         18207 non-null int64
    Nationality                 18207 non-null object
    Overall                     18207 non-null int64
    Potential                   18207 non-null int64
    Club                        17966 non-null object
    Value                       18207 non-null object
    Wage                        18207 non-null object
    Preferred Foot              18159 non-null object
    International Reputation    18159 non-null float64
    Weak Foot                   18159 non-null float64
    Skill Moves                 18159 non-null float64
    Work Rate                   18159 non-null object
    Position                    18147 non-null object
    Jersey Number               18147 non-null float64
    Height                      18159 non-null object
    Crossing                    18159 non-null float64
    Finishing                   18159 non-null float64
    HeadingAccuracy             18159 non-null float64
    ShortPassing                18159 non-null float64
    Volleys                     18159 non-null float64
    Dribbling                   18159 non-null float64
    Curve                       18159 non-null float64
    FKAccuracy                  18159 non-null float64
    LongPassing                 18159 non-null float64
    BallControl                 18159 non-null float64
    Acceleration                18159 non-null float64
    SprintSpeed                 18159 non-null float64
    Agility                     18159 non-null float64
    Reactions                   18159 non-null float64
    Balance                     18159 non-null float64
    ShotPower                   18159 non-null float64
    Jumping                     18159 non-null float64
    Stamina                     18159 non-null float64
    Strength                    18159 non-null float64
    LongShots                   18159 non-null float64
    Aggression                  18159 non-null float64
    Interceptions               18159 non-null float64
    Positioning                 18159 non-null float64
    Vision                      18159 non-null float64
    Penalties                   18159 non-null float64
    Composure                   18159 non-null float64
    Marking                     18159 non-null float64
    StandingTackle              18159 non-null float64
    SlidingTackle               18159 non-null float64
    GKDiving                    18159 non-null float64
    GKHandling                  18159 non-null float64
    GKKicking                   18159 non-null float64
    GKPositioning               18159 non-null float64
    GKReflexes                  18159 non-null float64
    dtypes: float64(38), int64(3), object(9)
    memory usage: 6.3+ MB
    

STATISTICS ON DATASET

.. code:: ipython3

    df_fifa.describe()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Age</th>
          <th>Overall</th>
          <th>Potential</th>
          <th>International Reputation</th>
          <th>Weak Foot</th>
          <th>Skill Moves</th>
          <th>Jersey Number</th>
          <th>Crossing</th>
          <th>Finishing</th>
          <th>HeadingAccuracy</th>
          <th>...</th>
          <th>Penalties</th>
          <th>Composure</th>
          <th>Marking</th>
          <th>StandingTackle</th>
          <th>SlidingTackle</th>
          <th>GKDiving</th>
          <th>GKHandling</th>
          <th>GKKicking</th>
          <th>GKPositioning</th>
          <th>GKReflexes</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>count</th>
          <td>18207.000000</td>
          <td>18207.000000</td>
          <td>18207.000000</td>
          <td>18159.000000</td>
          <td>18159.000000</td>
          <td>18159.000000</td>
          <td>18147.000000</td>
          <td>18159.000000</td>
          <td>18159.000000</td>
          <td>18159.000000</td>
          <td>...</td>
          <td>18159.000000</td>
          <td>18159.000000</td>
          <td>18159.000000</td>
          <td>18159.000000</td>
          <td>18159.000000</td>
          <td>18159.000000</td>
          <td>18159.000000</td>
          <td>18159.000000</td>
          <td>18159.000000</td>
          <td>18159.000000</td>
        </tr>
        <tr>
          <th>mean</th>
          <td>25.122206</td>
          <td>66.238699</td>
          <td>71.307299</td>
          <td>1.113222</td>
          <td>2.947299</td>
          <td>2.361308</td>
          <td>19.546096</td>
          <td>49.734181</td>
          <td>45.550911</td>
          <td>52.298144</td>
          <td>...</td>
          <td>48.548598</td>
          <td>58.648274</td>
          <td>47.281623</td>
          <td>47.697836</td>
          <td>45.661435</td>
          <td>16.616223</td>
          <td>16.391596</td>
          <td>16.232061</td>
          <td>16.388898</td>
          <td>16.710887</td>
        </tr>
        <tr>
          <th>std</th>
          <td>4.669943</td>
          <td>6.908930</td>
          <td>6.136496</td>
          <td>0.394031</td>
          <td>0.660456</td>
          <td>0.756164</td>
          <td>15.947765</td>
          <td>18.364524</td>
          <td>19.525820</td>
          <td>17.379909</td>
          <td>...</td>
          <td>15.704053</td>
          <td>11.436133</td>
          <td>19.904397</td>
          <td>21.664004</td>
          <td>21.289135</td>
          <td>17.695349</td>
          <td>16.906900</td>
          <td>16.502864</td>
          <td>17.034669</td>
          <td>17.955119</td>
        </tr>
        <tr>
          <th>min</th>
          <td>16.000000</td>
          <td>46.000000</td>
          <td>48.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>5.000000</td>
          <td>2.000000</td>
          <td>4.000000</td>
          <td>...</td>
          <td>5.000000</td>
          <td>3.000000</td>
          <td>3.000000</td>
          <td>2.000000</td>
          <td>3.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
        </tr>
        <tr>
          <th>25%</th>
          <td>21.000000</td>
          <td>62.000000</td>
          <td>67.000000</td>
          <td>1.000000</td>
          <td>3.000000</td>
          <td>2.000000</td>
          <td>8.000000</td>
          <td>38.000000</td>
          <td>30.000000</td>
          <td>44.000000</td>
          <td>...</td>
          <td>39.000000</td>
          <td>51.000000</td>
          <td>30.000000</td>
          <td>27.000000</td>
          <td>24.000000</td>
          <td>8.000000</td>
          <td>8.000000</td>
          <td>8.000000</td>
          <td>8.000000</td>
          <td>8.000000</td>
        </tr>
        <tr>
          <th>50%</th>
          <td>25.000000</td>
          <td>66.000000</td>
          <td>71.000000</td>
          <td>1.000000</td>
          <td>3.000000</td>
          <td>2.000000</td>
          <td>17.000000</td>
          <td>54.000000</td>
          <td>49.000000</td>
          <td>56.000000</td>
          <td>...</td>
          <td>49.000000</td>
          <td>60.000000</td>
          <td>53.000000</td>
          <td>55.000000</td>
          <td>52.000000</td>
          <td>11.000000</td>
          <td>11.000000</td>
          <td>11.000000</td>
          <td>11.000000</td>
          <td>11.000000</td>
        </tr>
        <tr>
          <th>75%</th>
          <td>28.000000</td>
          <td>71.000000</td>
          <td>75.000000</td>
          <td>1.000000</td>
          <td>3.000000</td>
          <td>3.000000</td>
          <td>26.000000</td>
          <td>64.000000</td>
          <td>62.000000</td>
          <td>64.000000</td>
          <td>...</td>
          <td>60.000000</td>
          <td>67.000000</td>
          <td>64.000000</td>
          <td>66.000000</td>
          <td>64.000000</td>
          <td>14.000000</td>
          <td>14.000000</td>
          <td>14.000000</td>
          <td>14.000000</td>
          <td>14.000000</td>
        </tr>
        <tr>
          <th>max</th>
          <td>45.000000</td>
          <td>94.000000</td>
          <td>95.000000</td>
          <td>5.000000</td>
          <td>5.000000</td>
          <td>5.000000</td>
          <td>99.000000</td>
          <td>93.000000</td>
          <td>95.000000</td>
          <td>94.000000</td>
          <td>...</td>
          <td>92.000000</td>
          <td>96.000000</td>
          <td>94.000000</td>
          <td>93.000000</td>
          <td>91.000000</td>
          <td>90.000000</td>
          <td>92.000000</td>
          <td>91.000000</td>
          <td>90.000000</td>
          <td>94.000000</td>
        </tr>
      </tbody>
    </table>
    <p>8 rows × 41 columns</p>
    </div>



ELEMENTS IN DATASETS

.. code:: ipython3

    df_fifa.nunique()




.. parsed-literal::

    Name                        17194
    Age                            29
    Nationality                   164
    Overall                        48
    Potential                      47
    Club                          651
    Value                         217
    Wage                          144
    Preferred Foot                  2
    International Reputation        5
    Weak Foot                       5
    Skill Moves                     5
    Work Rate                       9
    Position                       27
    Jersey Number                  99
    Height                         21
    Crossing                       89
    Finishing                      93
    HeadingAccuracy                91
    ShortPassing                   85
    Volleys                        87
    Dribbling                      94
    Curve                          89
    FKAccuracy                     90
    LongPassing                    84
    BallControl                    90
    Acceleration                   86
    SprintSpeed                    85
    Agility                        81
    Reactions                      68
    Balance                        81
    ShotPower                      92
    Jumping                        74
    Stamina                        85
    Strength                       74
    LongShots                      92
    Aggression                     85
    Interceptions                  89
    Positioning                    94
    Vision                         85
    Penalties                      87
    Composure                      84
    Marking                        92
    StandingTackle                 90
    SlidingTackle                  88
    GKDiving                       71
    GKHandling                     70
    GKKicking                      79
    GKPositioning                  79
    GKReflexes                     76
    dtype: int64



EXPLORATORY DATA ANALYSIS
~~~~~~~~~~~~~~~~~~~~~~~~~

HIGHEST RATED PLAYERS IN FIFA19

.. code:: ipython3

    df_fifa.sort_values(by = "Overall", ascending = False)[["Name", "Position", "Nationality", "Club", "Age", "Overall"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Position</th>
          <th>Nationality</th>
          <th>Club</th>
          <th>Age</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>L. Messi</td>
          <td>RF</td>
          <td>Argentina</td>
          <td>FC Barcelona</td>
          <td>31</td>
          <td>94</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Cristiano Ronaldo</td>
          <td>ST</td>
          <td>Portugal</td>
          <td>Juventus</td>
          <td>33</td>
          <td>94</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Neymar Jr</td>
          <td>LW</td>
          <td>Brazil</td>
          <td>Paris Saint-Germain</td>
          <td>26</td>
          <td>92</td>
        </tr>
        <tr>
          <th>3</th>
          <td>De Gea</td>
          <td>GK</td>
          <td>Spain</td>
          <td>Manchester United</td>
          <td>27</td>
          <td>91</td>
        </tr>
        <tr>
          <th>4</th>
          <td>K. De Bruyne</td>
          <td>RCM</td>
          <td>Belgium</td>
          <td>Manchester City</td>
          <td>27</td>
          <td>91</td>
        </tr>
      </tbody>
    </table>
    </div>



LOWEST RATED PLAYERS IN FIFA19

.. code:: ipython3

    df_fifa.sort_values(by = "Overall", ascending = True)[["Name", "Position", "Nationality", "Club", "Age", "Overall"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Position</th>
          <th>Nationality</th>
          <th>Club</th>
          <th>Age</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>18206</th>
          <td>G. Nugent</td>
          <td>CM</td>
          <td>England</td>
          <td>Tranmere Rovers</td>
          <td>16</td>
          <td>46</td>
        </tr>
        <tr>
          <th>18186</th>
          <td>Zhang Yufeng</td>
          <td>CM</td>
          <td>China PR</td>
          <td>Beijing Renhe FC</td>
          <td>20</td>
          <td>47</td>
        </tr>
        <tr>
          <th>18187</th>
          <td>C. Ehlich</td>
          <td>RB</td>
          <td>Germany</td>
          <td>SpVgg Unterhaching</td>
          <td>19</td>
          <td>47</td>
        </tr>
        <tr>
          <th>18188</th>
          <td>L. Collins</td>
          <td>CM</td>
          <td>Wales</td>
          <td>Newport County</td>
          <td>17</td>
          <td>47</td>
        </tr>
        <tr>
          <th>18189</th>
          <td>A. Kaltner</td>
          <td>ST</td>
          <td>Germany</td>
          <td>SpVgg Unterhaching</td>
          <td>18</td>
          <td>47</td>
        </tr>
      </tbody>
    </table>
    </div>



PLAYERS WITH BEST POTENTIAL

.. code:: ipython3

    df_fifa.sort_values(by = "Potential", ascending = False)[["Name", "Position", "Potential", "Club", "Age", "Overall"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Position</th>
          <th>Potential</th>
          <th>Club</th>
          <th>Age</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>25</th>
          <td>K. Mbappé</td>
          <td>RM</td>
          <td>95</td>
          <td>Paris Saint-Germain</td>
          <td>19</td>
          <td>88</td>
        </tr>
        <tr>
          <th>0</th>
          <td>L. Messi</td>
          <td>RF</td>
          <td>94</td>
          <td>FC Barcelona</td>
          <td>31</td>
          <td>94</td>
        </tr>
        <tr>
          <th>15</th>
          <td>P. Dybala</td>
          <td>LF</td>
          <td>94</td>
          <td>Juventus</td>
          <td>24</td>
          <td>89</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Cristiano Ronaldo</td>
          <td>ST</td>
          <td>94</td>
          <td>Juventus</td>
          <td>33</td>
          <td>94</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Neymar Jr</td>
          <td>LW</td>
          <td>93</td>
          <td>Paris Saint-Germain</td>
          <td>26</td>
          <td>92</td>
        </tr>
      </tbody>
    </table>
    </div>



OLDEST PLAYERS

.. code:: ipython3

    df_fifa.sort_values(by = "Age", ascending = False)[["Name", "Position", "Potential", "Club", "Age", "Overall"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Position</th>
          <th>Potential</th>
          <th>Club</th>
          <th>Age</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>4741</th>
          <td>O. Pérez</td>
          <td>GK</td>
          <td>71</td>
          <td>Pachuca</td>
          <td>45</td>
          <td>71</td>
        </tr>
        <tr>
          <th>18183</th>
          <td>K. Pilkington</td>
          <td>GK</td>
          <td>48</td>
          <td>Cambridge United</td>
          <td>44</td>
          <td>48</td>
        </tr>
        <tr>
          <th>17726</th>
          <td>T. Warner</td>
          <td>GK</td>
          <td>53</td>
          <td>Accrington Stanley</td>
          <td>44</td>
          <td>53</td>
        </tr>
        <tr>
          <th>10545</th>
          <td>S. Narazaki</td>
          <td>GK</td>
          <td>65</td>
          <td>Nagoya Grampus</td>
          <td>42</td>
          <td>65</td>
        </tr>
        <tr>
          <th>7225</th>
          <td>C. Muñoz</td>
          <td>GK</td>
          <td>68</td>
          <td>CD Universidad de Concepción</td>
          <td>41</td>
          <td>68</td>
        </tr>
      </tbody>
    </table>
    </div>



YOUNGEST PLAYERS

.. code:: ipython3

    df_fifa.sort_values(by = "Age", ascending = True)[["Name", "Position", "Potential", "Club", "Age", "Overall"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Position</th>
          <th>Potential</th>
          <th>Club</th>
          <th>Age</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>18206</th>
          <td>G. Nugent</td>
          <td>CM</td>
          <td>66</td>
          <td>Tranmere Rovers</td>
          <td>16</td>
          <td>46</td>
        </tr>
        <tr>
          <th>17743</th>
          <td>J. Olstad</td>
          <td>ST</td>
          <td>69</td>
          <td>Sarpsborg 08 FF</td>
          <td>16</td>
          <td>52</td>
        </tr>
        <tr>
          <th>13293</th>
          <td>H. Massengo</td>
          <td>CDM</td>
          <td>75</td>
          <td>AS Monaco</td>
          <td>16</td>
          <td>62</td>
        </tr>
        <tr>
          <th>16081</th>
          <td>J. Italiano</td>
          <td>LM</td>
          <td>79</td>
          <td>Perth Glory</td>
          <td>16</td>
          <td>58</td>
        </tr>
        <tr>
          <th>18166</th>
          <td>N. Ayéva</td>
          <td>ST</td>
          <td>72</td>
          <td>Örebro SK</td>
          <td>16</td>
          <td>48</td>
        </tr>
      </tbody>
    </table>
    </div>



PLAYERS WITH BEST SHOTPOWER

.. code:: ipython3

    df_fifa.sort_values(by = "ShotPower", ascending = False)[["Name", "Club", "Position", "ShotPower", "Overall"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Club</th>
          <th>Position</th>
          <th>ShotPower</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>1</th>
          <td>Cristiano Ronaldo</td>
          <td>Juventus</td>
          <td>ST</td>
          <td>95.0</td>
          <td>94</td>
        </tr>
        <tr>
          <th>378</th>
          <td>Hulk</td>
          <td>Shanghai SIPG FC</td>
          <td>RCM</td>
          <td>94.0</td>
          <td>81</td>
        </tr>
        <tr>
          <th>1348</th>
          <td>F. Guarín</td>
          <td>Shanghai Greenland Shenhua FC</td>
          <td>LDM</td>
          <td>93.0</td>
          <td>76</td>
        </tr>
        <tr>
          <th>890</th>
          <td>L. Podolski</td>
          <td>Vissel Kobe</td>
          <td>RF</td>
          <td>92.0</td>
          <td>78</td>
        </tr>
        <tr>
          <th>36</th>
          <td>G. Bale</td>
          <td>Real Madrid</td>
          <td>ST</td>
          <td>92.0</td>
          <td>88</td>
        </tr>
      </tbody>
    </table>
    </div>



BEST DRIBBLERS IN THE GAME

.. code:: ipython3

    df_fifa.sort_values(by = "Dribbling", ascending = False)[["Name", "Club", "Position", "Dribbling", "Overall"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Club</th>
          <th>Position</th>
          <th>Dribbling</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>L. Messi</td>
          <td>FC Barcelona</td>
          <td>RF</td>
          <td>97.0</td>
          <td>94</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Neymar Jr</td>
          <td>Paris Saint-Germain</td>
          <td>LW</td>
          <td>96.0</td>
          <td>92</td>
        </tr>
        <tr>
          <th>5</th>
          <td>E. Hazard</td>
          <td>Chelsea</td>
          <td>LF</td>
          <td>95.0</td>
          <td>91</td>
        </tr>
        <tr>
          <th>30</th>
          <td>Isco</td>
          <td>Real Madrid</td>
          <td>LW</td>
          <td>94.0</td>
          <td>88</td>
        </tr>
        <tr>
          <th>94</th>
          <td>Y. Brahimi</td>
          <td>FC Porto</td>
          <td>LM</td>
          <td>93.0</td>
          <td>85</td>
        </tr>
      </tbody>
    </table>
    </div>



BEST CROSSERS OF THE BALL

.. code:: ipython3

    df_fifa.sort_values(by = "Crossing", ascending = False)[["Name", "Club", "Position", "Crossing", "Overall"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Club</th>
          <th>Position</th>
          <th>Crossing</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>4</th>
          <td>K. De Bruyne</td>
          <td>Manchester City</td>
          <td>RCM</td>
          <td>93.0</td>
          <td>91</td>
        </tr>
        <tr>
          <th>153</th>
          <td>Quaresma</td>
          <td>Beşiktaş JK</td>
          <td>RM</td>
          <td>92.0</td>
          <td>84</td>
        </tr>
        <tr>
          <th>390</th>
          <td>Pedro León</td>
          <td>SD Eibar</td>
          <td>RM</td>
          <td>91.0</td>
          <td>81</td>
        </tr>
        <tr>
          <th>290</th>
          <td>K. Trippier</td>
          <td>Tottenham Hotspur</td>
          <td>RB</td>
          <td>91.0</td>
          <td>82</td>
        </tr>
        <tr>
          <th>291</th>
          <td>A. Kolarov</td>
          <td>Roma</td>
          <td>LB</td>
          <td>91.0</td>
          <td>82</td>
        </tr>
      </tbody>
    </table>
    </div>



BEST FREEKICK TAKERS

.. code:: ipython3

    df_fifa.sort_values(by = "FKAccuracy", ascending = False)[["Name", "Club", "Position", "FKAccuracy", "Overall"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Club</th>
          <th>Position</th>
          <th>FKAccuracy</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>L. Messi</td>
          <td>FC Barcelona</td>
          <td>RF</td>
          <td>94.0</td>
          <td>94</td>
        </tr>
        <tr>
          <th>293</th>
          <td>S. Giovinco</td>
          <td>Toronto FC</td>
          <td>CF</td>
          <td>93.0</td>
          <td>82</td>
        </tr>
        <tr>
          <th>72</th>
          <td>M. Pjanić</td>
          <td>Juventus</td>
          <td>CDM</td>
          <td>92.0</td>
          <td>86</td>
        </tr>
        <tr>
          <th>1113</th>
          <td>E. Bardhi</td>
          <td>Levante UD</td>
          <td>LCM</td>
          <td>91.0</td>
          <td>77</td>
        </tr>
        <tr>
          <th>449</th>
          <td>H. Çalhanoğlu</td>
          <td>Milan</td>
          <td>CAM</td>
          <td>90.0</td>
          <td>80</td>
        </tr>
      </tbody>
    </table>
    </div>



PLAYERS HAVING BEST BALL CONTROL

.. code:: ipython3

    df_fifa.sort_values(by = "BallControl", ascending = False)[["Name", "Club", "Position", "BallControl", "Overall"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Club</th>
          <th>Position</th>
          <th>BallControl</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>L. Messi</td>
          <td>FC Barcelona</td>
          <td>RF</td>
          <td>96.0</td>
          <td>94</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Neymar Jr</td>
          <td>Paris Saint-Germain</td>
          <td>LW</td>
          <td>95.0</td>
          <td>92</td>
        </tr>
        <tr>
          <th>30</th>
          <td>Isco</td>
          <td>Real Madrid</td>
          <td>LW</td>
          <td>95.0</td>
          <td>88</td>
        </tr>
        <tr>
          <th>5</th>
          <td>E. Hazard</td>
          <td>Chelsea</td>
          <td>LF</td>
          <td>94.0</td>
          <td>91</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Cristiano Ronaldo</td>
          <td>Juventus</td>
          <td>ST</td>
          <td>94.0</td>
          <td>94</td>
        </tr>
      </tbody>
    </table>
    </div>



PLAYERS WITH BEST VISION

.. code:: ipython3

    df_fifa.sort_values(by = "Vision" , ascending = False)[["Name", "Club" ,"Nationality" ,"Vision", "Overall" ]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Club</th>
          <th>Nationality</th>
          <th>Vision</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>L. Messi</td>
          <td>FC Barcelona</td>
          <td>Argentina</td>
          <td>94.0</td>
          <td>94</td>
        </tr>
        <tr>
          <th>4</th>
          <td>K. De Bruyne</td>
          <td>Manchester City</td>
          <td>Belgium</td>
          <td>94.0</td>
          <td>91</td>
        </tr>
        <tr>
          <th>76</th>
          <td>Iniesta</td>
          <td>Vissel Kobe</td>
          <td>Spain</td>
          <td>93.0</td>
          <td>86</td>
        </tr>
        <tr>
          <th>13</th>
          <td>David Silva</td>
          <td>Manchester City</td>
          <td>Spain</td>
          <td>92.0</td>
          <td>90</td>
        </tr>
        <tr>
          <th>6</th>
          <td>L. Modrić</td>
          <td>Real Madrid</td>
          <td>Croatia</td>
          <td>92.0</td>
          <td>91</td>
        </tr>
      </tbody>
    </table>
    </div>



BEST FINISHERS

.. code:: ipython3

    df_fifa.sort_values(by = "Finishing", ascending = False)[["Name", "Club", "Position", "Finishing", "Overall"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Club</th>
          <th>Position</th>
          <th>Finishing</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>L. Messi</td>
          <td>FC Barcelona</td>
          <td>RF</td>
          <td>95.0</td>
          <td>94</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Cristiano Ronaldo</td>
          <td>Juventus</td>
          <td>ST</td>
          <td>94.0</td>
          <td>94</td>
        </tr>
        <tr>
          <th>16</th>
          <td>H. Kane</td>
          <td>Tottenham Hotspur</td>
          <td>ST</td>
          <td>94.0</td>
          <td>89</td>
        </tr>
        <tr>
          <th>23</th>
          <td>S. Agüero</td>
          <td>Manchester City</td>
          <td>ST</td>
          <td>93.0</td>
          <td>89</td>
        </tr>
        <tr>
          <th>7</th>
          <td>L. Suárez</td>
          <td>FC Barcelona</td>
          <td>RS</td>
          <td>93.0</td>
          <td>91</td>
        </tr>
      </tbody>
    </table>
    </div>



PLAYERS WITH FAST ACCELERATION

.. code:: ipython3

    df_fifa.sort_values(by = "Acceleration", ascending = False)[["Name", "Club", "Position", "Acceleration", "Overall"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Club</th>
          <th>Position</th>
          <th>Acceleration</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>1968</th>
          <td>Adama</td>
          <td>Wolverhampton Wanderers</td>
          <td>RW</td>
          <td>97.0</td>
          <td>75</td>
        </tr>
        <tr>
          <th>65</th>
          <td>Douglas Costa</td>
          <td>Juventus</td>
          <td>LM</td>
          <td>97.0</td>
          <td>86</td>
        </tr>
        <tr>
          <th>5886</th>
          <td>K. Manneh</td>
          <td>FC St. Gallen</td>
          <td>LM</td>
          <td>96.0</td>
          <td>69</td>
        </tr>
        <tr>
          <th>25</th>
          <td>K. Mbappé</td>
          <td>Paris Saint-Germain</td>
          <td>RM</td>
          <td>96.0</td>
          <td>88</td>
        </tr>
        <tr>
          <th>2587</th>
          <td>J. Biabiany</td>
          <td>Parma</td>
          <td>RW</td>
          <td>95.0</td>
          <td>74</td>
        </tr>
      </tbody>
    </table>
    </div>



BEST SPRINTERS

.. code:: ipython3

    df_fifa.sort_values(by = "SprintSpeed", ascending = False)[["Name", "Club", "Position", "SprintSpeed", "Overall"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Club</th>
          <th>Position</th>
          <th>SprintSpeed</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>1968</th>
          <td>Adama</td>
          <td>Wolverhampton Wanderers</td>
          <td>RW</td>
          <td>96.0</td>
          <td>75</td>
        </tr>
        <tr>
          <th>55</th>
          <td>L. Sané</td>
          <td>Manchester City</td>
          <td>LW</td>
          <td>96.0</td>
          <td>86</td>
        </tr>
        <tr>
          <th>25</th>
          <td>K. Mbappé</td>
          <td>Paris Saint-Germain</td>
          <td>RM</td>
          <td>96.0</td>
          <td>88</td>
        </tr>
        <tr>
          <th>1489</th>
          <td>I. Bebou</td>
          <td>Hannover 96</td>
          <td>RM</td>
          <td>95.0</td>
          <td>76</td>
        </tr>
        <tr>
          <th>36</th>
          <td>G. Bale</td>
          <td>Real Madrid</td>
          <td>ST</td>
          <td>95.0</td>
          <td>88</td>
        </tr>
      </tbody>
    </table>
    </div>



BEST LONG PASSERS IN THE GAME

.. code:: ipython3

    df_fifa.sort_values(by = "LongPassing", ascending = False)[["Name", "Club", "Position", "LongPassing", "Overall"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Club</th>
          <th>Position</th>
          <th>LongPassing</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>11</th>
          <td>T. Kroos</td>
          <td>Real Madrid</td>
          <td>LCM</td>
          <td>93.0</td>
          <td>90</td>
        </tr>
        <tr>
          <th>4</th>
          <td>K. De Bruyne</td>
          <td>Manchester City</td>
          <td>RCM</td>
          <td>91.0</td>
          <td>91</td>
        </tr>
        <tr>
          <th>45</th>
          <td>P. Pogba</td>
          <td>Manchester United</td>
          <td>RDM</td>
          <td>90.0</td>
          <td>87</td>
        </tr>
        <tr>
          <th>53</th>
          <td>I. Rakitić</td>
          <td>FC Barcelona</td>
          <td>RCM</td>
          <td>90.0</td>
          <td>87</td>
        </tr>
        <tr>
          <th>219</th>
          <td>Cesc Fàbregas</td>
          <td>Chelsea</td>
          <td>CM</td>
          <td>89.0</td>
          <td>83</td>
        </tr>
      </tbody>
    </table>
    </div>



STRONGEST PLAYERS

.. code:: ipython3

    df_fifa.sort_values(by = "Strength", ascending = False)[["Name", "Club", "Position", "Strength", "Overall"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Club</th>
          <th>Position</th>
          <th>Strength</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>9501</th>
          <td>A. Akinfenwa</td>
          <td>Wycombe Wanderers</td>
          <td>LS</td>
          <td>97.0</td>
          <td>66</td>
        </tr>
        <tr>
          <th>1124</th>
          <td>Wesley</td>
          <td>Club Brugge KV</td>
          <td>LS</td>
          <td>95.0</td>
          <td>77</td>
        </tr>
        <tr>
          <th>2559</th>
          <td>K. Waston</td>
          <td>Vancouver Whitecaps FC</td>
          <td>RCB</td>
          <td>95.0</td>
          <td>74</td>
        </tr>
        <tr>
          <th>14111</th>
          <td>T. Chorý</td>
          <td>Viktoria Plzeň</td>
          <td>ST</td>
          <td>95.0</td>
          <td>61</td>
        </tr>
        <tr>
          <th>15179</th>
          <td>M. Rhead</td>
          <td>Lincoln City</td>
          <td>ST</td>
          <td>94.0</td>
          <td>60</td>
        </tr>
      </tbody>
    </table>
    </div>



MOST AGGRESIVE PLAYERS

.. code:: ipython3

    df_fifa.sort_values(by = "Aggression", ascending = False)[["Name", "Club", "Position", "Aggression", "Overall"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Club</th>
          <th>Position</th>
          <th>Aggression</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>1948</th>
          <td>B. Pearson</td>
          <td>Preston North End</td>
          <td>RDM</td>
          <td>95.0</td>
          <td>75</td>
        </tr>
        <tr>
          <th>9512</th>
          <td>D. Erdmann</td>
          <td>1. FC Magdeburg</td>
          <td>CB</td>
          <td>94.0</td>
          <td>66</td>
        </tr>
        <tr>
          <th>940</th>
          <td>Gazzolisco</td>
          <td>Internacional</td>
          <td>LB</td>
          <td>94.0</td>
          <td>77</td>
        </tr>
        <tr>
          <th>16919</th>
          <td>D. Pipe</td>
          <td>Newport County</td>
          <td>RWB</td>
          <td>94.0</td>
          <td>56</td>
        </tr>
        <tr>
          <th>4037</th>
          <td>J. Garner</td>
          <td>Wigan Athletic</td>
          <td>ST</td>
          <td>94.0</td>
          <td>71</td>
        </tr>
      </tbody>
    </table>
    </div>



BEST GOAL KEEPERS (REFLEXES)

.. code:: ipython3

    df_fifa.sort_values(by = "GKReflexes", ascending = False)[["Name", "Club", "Position", "GKReflexes", "Overall"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Club</th>
          <th>Position</th>
          <th>GKReflexes</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>3</th>
          <td>De Gea</td>
          <td>Manchester United</td>
          <td>GK</td>
          <td>94.0</td>
          <td>91</td>
        </tr>
        <tr>
          <th>37</th>
          <td>H. Lloris</td>
          <td>Tottenham Hotspur</td>
          <td>GK</td>
          <td>92.0</td>
          <td>88</td>
        </tr>
        <tr>
          <th>18</th>
          <td>M. ter Stegen</td>
          <td>FC Barcelona</td>
          <td>GK</td>
          <td>90.0</td>
          <td>89</td>
        </tr>
        <tr>
          <th>128</th>
          <td>M. Perin</td>
          <td>Juventus</td>
          <td>GK</td>
          <td>90.0</td>
          <td>84</td>
        </tr>
        <tr>
          <th>46</th>
          <td>K. Navas</td>
          <td>Real Madrid</td>
          <td>GK</td>
          <td>90.0</td>
          <td>87</td>
        </tr>
      </tbody>
    </table>
    </div>



BEST GOAL KEEPERS (DIVING)

.. code:: ipython3

    df_fifa.sort_values(by = "GKDiving", ascending = False)[["Name", "Club", "Position", "GKDiving", "Overall"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Club</th>
          <th>Position</th>
          <th>GKDiving</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>22</th>
          <td>M. Neuer</td>
          <td>FC Bayern München</td>
          <td>GK</td>
          <td>90.0</td>
          <td>89</td>
        </tr>
        <tr>
          <th>46</th>
          <td>K. Navas</td>
          <td>Real Madrid</td>
          <td>GK</td>
          <td>90.0</td>
          <td>87</td>
        </tr>
        <tr>
          <th>3</th>
          <td>De Gea</td>
          <td>Manchester United</td>
          <td>GK</td>
          <td>90.0</td>
          <td>91</td>
        </tr>
        <tr>
          <th>37</th>
          <td>H. Lloris</td>
          <td>Tottenham Hotspur</td>
          <td>GK</td>
          <td>88.0</td>
          <td>88</td>
        </tr>
        <tr>
          <th>41</th>
          <td>G. Buffon</td>
          <td>Paris Saint-Germain</td>
          <td>GK</td>
          <td>88.0</td>
          <td>88</td>
        </tr>
      </tbody>
    </table>
    </div>



BEST DEFENDERS (SLIDING TACKLE)

.. code:: ipython3

    df_fifa.sort_values(by = "SlidingTackle", ascending = False)[["Name", "Club", "Nationality", "SlidingTackle", "Overall"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Club</th>
          <th>Nationality</th>
          <th>SlidingTackle</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>8</th>
          <td>Sergio Ramos</td>
          <td>Real Madrid</td>
          <td>Spain</td>
          <td>91.0</td>
          <td>91</td>
        </tr>
        <tr>
          <th>101</th>
          <td>R. Nainggolan</td>
          <td>Inter</td>
          <td>Belgium</td>
          <td>90.0</td>
          <td>85</td>
        </tr>
        <tr>
          <th>24</th>
          <td>G. Chiellini</td>
          <td>Juventus</td>
          <td>Italy</td>
          <td>90.0</td>
          <td>89</td>
        </tr>
        <tr>
          <th>88</th>
          <td>K. Manolas</td>
          <td>Roma</td>
          <td>Greece</td>
          <td>89.0</td>
          <td>85</td>
        </tr>
        <tr>
          <th>12</th>
          <td>D. Godín</td>
          <td>Atlético Madrid</td>
          <td>Uruguay</td>
          <td>89.0</td>
          <td>90</td>
        </tr>
      </tbody>
    </table>
    </div>



BEST DEFENDERS (STANDING TACKLE)

.. code:: ipython3

    df_fifa.sort_values(by = "StandingTackle", ascending = False)[["Name", "Club", "Nationality", "StandingTackle", "Overall"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Club</th>
          <th>Nationality</th>
          <th>StandingTackle</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>24</th>
          <td>G. Chiellini</td>
          <td>Juventus</td>
          <td>Italy</td>
          <td>93.0</td>
          <td>89</td>
        </tr>
        <tr>
          <th>8</th>
          <td>Sergio Ramos</td>
          <td>Real Madrid</td>
          <td>Spain</td>
          <td>92.0</td>
          <td>91</td>
        </tr>
        <tr>
          <th>71</th>
          <td>T. Alderweireld</td>
          <td>Tottenham Hotspur</td>
          <td>Belgium</td>
          <td>91.0</td>
          <td>86</td>
        </tr>
        <tr>
          <th>14</th>
          <td>N. Kanté</td>
          <td>Chelsea</td>
          <td>France</td>
          <td>91.0</td>
          <td>89</td>
        </tr>
        <tr>
          <th>27</th>
          <td>Casemiro</td>
          <td>Real Madrid</td>
          <td>Brazil</td>
          <td>90.0</td>
          <td>88</td>
        </tr>
      </tbody>
    </table>
    </div>



NUMBER OF PLAYERS AT CERTAIN POSITIONS

.. code:: ipython3

    plt.figure(1, figsize = (15, 6))
    pos = sns.countplot(x = "Position", data = df_fifa, palette = "hls");
    pos.set_title(label="Number of players at specialized position", fontsize=40);
    plt.show()



.. image:: output_61_0.png


BEST LEFT FOOTED PLAYERS

.. code:: ipython3

    df_fifa[df_fifa["Preferred Foot"] == "Left"][["Name", "Club", "Position","Overall"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Club</th>
          <th>Position</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>L. Messi</td>
          <td>FC Barcelona</td>
          <td>RF</td>
          <td>94</td>
        </tr>
        <tr>
          <th>13</th>
          <td>David Silva</td>
          <td>Manchester City</td>
          <td>LCM</td>
          <td>90</td>
        </tr>
        <tr>
          <th>15</th>
          <td>P. Dybala</td>
          <td>Juventus</td>
          <td>LF</td>
          <td>89</td>
        </tr>
        <tr>
          <th>17</th>
          <td>A. Griezmann</td>
          <td>Atlético Madrid</td>
          <td>CAM</td>
          <td>89</td>
        </tr>
        <tr>
          <th>19</th>
          <td>T. Courtois</td>
          <td>Real Madrid</td>
          <td>GK</td>
          <td>89</td>
        </tr>
      </tbody>
    </table>
    </div>



BEST RIGHT FOOTED PLAYERS

.. code:: ipython3

    df_fifa[df_fifa["Preferred Foot"] == "Right"][["Name","Club", "Position", "Overall"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Club</th>
          <th>Position</th>
          <th>Overall</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>1</th>
          <td>Cristiano Ronaldo</td>
          <td>Juventus</td>
          <td>ST</td>
          <td>94</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Neymar Jr</td>
          <td>Paris Saint-Germain</td>
          <td>LW</td>
          <td>92</td>
        </tr>
        <tr>
          <th>3</th>
          <td>De Gea</td>
          <td>Manchester United</td>
          <td>GK</td>
          <td>91</td>
        </tr>
        <tr>
          <th>4</th>
          <td>K. De Bruyne</td>
          <td>Manchester City</td>
          <td>RCM</td>
          <td>91</td>
        </tr>
        <tr>
          <th>5</th>
          <td>E. Hazard</td>
          <td>Chelsea</td>
          <td>LF</td>
          <td>91</td>
        </tr>
      </tbody>
    </table>
    </div>



COMPARISON : LEFT FOOT VS RIGHT FOOT IN TERMS OF DRIBBLING AND FINISHING

.. code:: ipython3

    sns.lmplot(x = "Finishing", y = "Dribbling", data = df_fifa, scatter_kws = {"alpha":0.1}, col = "Preferred Foot");
    plt.show()



.. image:: output_67_0.png


ATTRIBUTES : PLAYER NAME

.. code:: ipython3

    cols = ["Crossing", "Potential", "Finishing", "HeadingAccuracy", "ShortPassing", "Volleys", 
            "Dribbling", "Curve", "FKAccuracy", "LongPassing", "BallControl", "Acceleration", 
            "SprintSpeed", "Agility", "Reactions", "Balance", "ShotPower", "Jumping", "Stamina", 
            "Strength", "LongShots", "Aggression", "Interceptions", "Positioning", "Vision", 
            "Penalties", "Composure", "Marking", "StandingTackle", "SlidingTackle", "GKDiving", 
            "GKHandling", "GKKicking", "GKPositioning", "GKReflexes"]
    i=0
    while i < len(cols):
        print('Best {0} : {1}'.format(cols[i], df_fifa.loc[df_fifa[cols[i]].idxmax()]["Name"]))
        i += 1


.. parsed-literal::

    Best Crossing : K. De Bruyne
    Best Potential : K. Mbappé
    Best Finishing : L. Messi
    Best HeadingAccuracy : Naldo
    Best ShortPassing : L. Modrić
    Best Volleys : E. Cavani
    Best Dribbling : L. Messi
    Best Curve : Quaresma
    Best FKAccuracy : L. Messi
    Best LongPassing : T. Kroos
    Best BallControl : L. Messi
    Best Acceleration : Douglas Costa
    Best SprintSpeed : K. Mbappé
    Best Agility : Neymar Jr
    Best Reactions : Cristiano Ronaldo
    Best Balance : Bernard
    Best ShotPower : Cristiano Ronaldo
    Best Jumping : Cristiano Ronaldo
    Best Stamina : N. Kanté
    Best Strength : A. Akinfenwa
    Best LongShots : L. Messi
    Best Aggression : B. Pearson
    Best Interceptions : N. Kanté
    Best Positioning : Cristiano Ronaldo
    Best Vision : L. Messi
    Best Penalties : M. Balotelli
    Best Composure : L. Messi
    Best Marking : A. Barzagli
    Best StandingTackle : G. Chiellini
    Best SlidingTackle : Sergio Ramos
    Best GKDiving : De Gea
    Best GKHandling : J. Oblak
    Best GKKicking : M. Neuer
    Best GKPositioning : G. Buffon
    Best GKReflexes : De Gea
    

BEST PLAYER AT EACH POSITION

.. code:: ipython3

    display(HTML(df_fifa.iloc[df_fifa.groupby(df_fifa["Position"])["Overall"].idxmax()][["Name", "Position"]].to_html(index=False)))



.. raw:: html

    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th>Name</th>
          <th>Position</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>A. Griezmann</td>
          <td>CAM</td>
        </tr>
        <tr>
          <td>D. Godín</td>
          <td>CB</td>
        </tr>
        <tr>
          <td>Sergio Busquets</td>
          <td>CDM</td>
        </tr>
        <tr>
          <td>Luis Alberto</td>
          <td>CF</td>
        </tr>
        <tr>
          <td>Thiago</td>
          <td>CM</td>
        </tr>
        <tr>
          <td>De Gea</td>
          <td>GK</td>
        </tr>
        <tr>
          <td>J. Rodríguez</td>
          <td>LAM</td>
        </tr>
        <tr>
          <td>Marcelo</td>
          <td>LB</td>
        </tr>
        <tr>
          <td>G. Chiellini</td>
          <td>LCB</td>
        </tr>
        <tr>
          <td>T. Kroos</td>
          <td>LCM</td>
        </tr>
        <tr>
          <td>N. Kanté</td>
          <td>LDM</td>
        </tr>
        <tr>
          <td>E. Hazard</td>
          <td>LF</td>
        </tr>
        <tr>
          <td>P. Aubameyang</td>
          <td>LM</td>
        </tr>
        <tr>
          <td>E. Cavani</td>
          <td>LS</td>
        </tr>
        <tr>
          <td>Neymar Jr</td>
          <td>LW</td>
        </tr>
        <tr>
          <td>N. Schulz</td>
          <td>LWB</td>
        </tr>
        <tr>
          <td>J. Cuadrado</td>
          <td>RAM</td>
        </tr>
        <tr>
          <td>Azpilicueta</td>
          <td>RB</td>
        </tr>
        <tr>
          <td>Sergio Ramos</td>
          <td>RCB</td>
        </tr>
        <tr>
          <td>K. De Bruyne</td>
          <td>RCM</td>
        </tr>
        <tr>
          <td>P. Pogba</td>
          <td>RDM</td>
        </tr>
        <tr>
          <td>L. Messi</td>
          <td>RF</td>
        </tr>
        <tr>
          <td>K. Mbappé</td>
          <td>RM</td>
        </tr>
        <tr>
          <td>L. Suárez</td>
          <td>RS</td>
        </tr>
        <tr>
          <td>Bernardo Silva</td>
          <td>RW</td>
        </tr>
        <tr>
          <td>M. Ginter</td>
          <td>RWB</td>
        </tr>
        <tr>
          <td>Cristiano Ronaldo</td>
          <td>ST</td>
        </tr>
      </tbody>
    </table>


TOP 3 FEATURES FOR EACH POSITION

.. code:: ipython3

    player_features = ["Crossing", "Potential", "Finishing", "HeadingAccuracy", "ShortPassing", "Volleys", 
            "Dribbling", "Curve", "FKAccuracy", "LongPassing", "BallControl", "Acceleration", 
            "SprintSpeed", "Agility", "Reactions", "Balance", "ShotPower", "Jumping", "Stamina", 
            "Strength", "LongShots", "Aggression", "Interceptions", "Positioning", "Vision", 
            "Penalties", "Composure", "Marking", "StandingTackle", "SlidingTackle", "GKDiving", 
            "GKHandling", "GKKicking", "GKPositioning", "GKReflexes"]
    
    for i, val in df_fifa.groupby(df_fifa["Position"])[player_features].mean().iterrows():
        print("Position {}: {}, {}, {}".format(i, *tuple(val.nlargest(3).index)))


.. parsed-literal::

    Position CAM: Balance, Potential, Agility
    Position CB: Strength, Potential, Jumping
    Position CDM: Potential, Stamina, Aggression
    Position CF: Agility, Balance, Acceleration
    Position CM: Potential, Balance, ShortPassing
    Position GK: Potential, GKReflexes, GKDiving
    Position LAM: Agility, Balance, SprintSpeed
    Position LB: SprintSpeed, Acceleration, Stamina
    Position LCB: Strength, Potential, Jumping
    Position LCM: Stamina, Potential, ShortPassing
    Position LDM: Stamina, Potential, ShortPassing
    Position LF: Balance, Agility, Acceleration
    Position LM: Acceleration, SprintSpeed, Agility
    Position LS: SprintSpeed, Potential, Strength
    Position LW: Acceleration, SprintSpeed, Agility
    Position LWB: SprintSpeed, Acceleration, Stamina
    Position RAM: Agility, Balance, Acceleration
    Position RB: SprintSpeed, Stamina, Acceleration
    Position RCB: Strength, Potential, Jumping
    Position RCM: Stamina, Potential, ShortPassing
    Position RDM: Stamina, Potential, ShortPassing
    Position RF: Agility, Potential, Acceleration
    Position RM: Acceleration, SprintSpeed, Agility
    Position RS: SprintSpeed, Potential, Strength
    Position RW: Acceleration, SprintSpeed, Agility
    Position RWB: SprintSpeed, Acceleration, Stamina
    Position ST: Potential, SprintSpeed, Strength
    

FREQUENCY OF OVERALL PLAYER RATINGS

.. code:: ipython3

    plt.figure(1, figsize = (15, 6))
    pos = sns.countplot(x = "Overall", data = df_fifa, palette = "hls");
    pos.set_title(label="Player Ratings out of 100", fontsize=40);
    plt.show()



.. image:: output_75_0.png


PLAYER POTENTIAL DISTRIBUTION

.. code:: ipython3

    plt.figure(1, figsize = (15, 6))
    pos = sns.countplot(x = "Potential", data = df_fifa, palette = "hls");
    pos.set_title(label="Player Potential Distribution", fontsize=40);
    plt.show()



.. image:: output_77_0.png


PLAYERS AGE DISTRIBUTION

.. code:: ipython3

    plt.figure(1, figsize = (15, 6))
    pos = sns.countplot(x = "Age", data = df_fifa, palette = "hls");
    pos.set_title(label="Age Distribution", fontsize=40);
    plt.show()



.. image:: output_79_0.png


AGE DISTRIBUTION IN TOP CLUBS IN EUROPE

.. code:: ipython3

    clubs = ["FC Barcelona", "Real Madrid", "Juventus", "Liverpool", "Manchester City", "Paris Saint-Germain"]
    df_club_age = df_fifa.loc[df_fifa["Club"].isin(clubs) & df_fifa["Age"]]
    plt.figure(1 , figsize = (15 ,7))
    sns.violinplot(x = "Club", y = "Age", data = df_club_age)
    plt.title("Age Distribution in Top European clubs")
    plt.xticks(rotation = 50)
    plt.show()



.. image:: output_81_0.png


CLUBS WITH MOST PLAYERS

.. code:: ipython3

    print("Total number of clubs : {0}".format(df_fifa["Club"].nunique()))
    print(df_fifa["Club"].value_counts().head(10))
    


.. parsed-literal::

    Total number of clubs : 651
    Borussia Dortmund          33
    Cardiff City               33
    Real Madrid                33
    Valencia CF                33
    Everton                    33
    Atlético Madrid            33
    Fortuna Düsseldorf         33
    CD Leganés                 33
    Frosinone                  33
    Wolverhampton Wanderers    33
    Name: Club, dtype: int64
    

BEST SQUAD SIZE

.. code:: ipython3

    plt.figure(1 , figsize = (15 , 5))
    club = []
    c = counter(df_fifa["Club"]).most_common()[:11]
    for n in range(11):club.append(c[n][0])
    
    sns.countplot(x = "Club", data = df_fifa[df_fifa["Club"].isin(club)], 
                  order  = df_fifa[df_fifa["Club"].isin(club)]["Club"].value_counts().index, palette = "rocket") 
    plt.xticks(rotation = 90)
    plt.title("Clubs with best squad size" )
    plt.show()



.. image:: output_85_0.png


CHANGING DATA FORMAT

.. code:: ipython3

    def cleaning_value(x):
        if '€' in str(x) and 'M' in str(x):
            c = str(x).replace('€' , '')
            c = str(c).replace('M' , '')
            c = float(c) * 1000000
            
        else:
            c = str(x).replace('€' , '')
            c = str(c).replace('K' , '')
            c = float(c) * 1000
                
        return c
    
    fn = lambda x : cleaning_value(x)
    
    df_fifa["Value_num"] = df_fifa["Value"].apply(fn)
    df_fifa["Wage_num"] = df_fifa["Wage"].apply(fn)

MOST VALUABLE PLAYERS

.. code:: ipython3

    df_fifa.sort_values(by = "Value_num", ascending = False)[["Name", "Club", "Nationality", "Overall", "Value"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Club</th>
          <th>Nationality</th>
          <th>Overall</th>
          <th>Value</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>2</th>
          <td>Neymar Jr</td>
          <td>Paris Saint-Germain</td>
          <td>Brazil</td>
          <td>92</td>
          <td>€118.5M</td>
        </tr>
        <tr>
          <th>0</th>
          <td>L. Messi</td>
          <td>FC Barcelona</td>
          <td>Argentina</td>
          <td>94</td>
          <td>€110.5M</td>
        </tr>
        <tr>
          <th>4</th>
          <td>K. De Bruyne</td>
          <td>Manchester City</td>
          <td>Belgium</td>
          <td>91</td>
          <td>€102M</td>
        </tr>
        <tr>
          <th>5</th>
          <td>E. Hazard</td>
          <td>Chelsea</td>
          <td>Belgium</td>
          <td>91</td>
          <td>€93M</td>
        </tr>
        <tr>
          <th>15</th>
          <td>P. Dybala</td>
          <td>Juventus</td>
          <td>Argentina</td>
          <td>89</td>
          <td>€89M</td>
        </tr>
      </tbody>
    </table>
    </div>



BEST PAID PLAYERS

.. code:: ipython3

    df_fifa.sort_values(by = "Wage_num", ascending = False)[["Name", "Club", "Nationality", "Overall", "Wage"]].head()




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Club</th>
          <th>Nationality</th>
          <th>Overall</th>
          <th>Wage</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>L. Messi</td>
          <td>FC Barcelona</td>
          <td>Argentina</td>
          <td>94</td>
          <td>€565K</td>
        </tr>
        <tr>
          <th>7</th>
          <td>L. Suárez</td>
          <td>FC Barcelona</td>
          <td>Uruguay</td>
          <td>91</td>
          <td>€455K</td>
        </tr>
        <tr>
          <th>6</th>
          <td>L. Modrić</td>
          <td>Real Madrid</td>
          <td>Croatia</td>
          <td>91</td>
          <td>€420K</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Cristiano Ronaldo</td>
          <td>Juventus</td>
          <td>Portugal</td>
          <td>94</td>
          <td>€405K</td>
        </tr>
        <tr>
          <th>8</th>
          <td>Sergio Ramos</td>
          <td>Real Madrid</td>
          <td>Spain</td>
          <td>91</td>
          <td>€380K</td>
        </tr>
      </tbody>
    </table>
    </div>



AGE DISTRIBUTION IN TOP COUNTRIES

.. code:: ipython3

    country = ["Argentina", "Brazil", "France", "Belgium", "England", "Spain", "Portugal"]
    df_country_age = df_fifa.loc[df_fifa["Nationality"].isin(country) & df_fifa["Age"]]
    plt.figure(1 , figsize = (15 ,7))
    sns.violinplot(x = "Nationality" , y = "Age" , data = df_country_age)
    plt.title("Age Distribution in Top National Teams")
    plt.xticks(rotation = 50)
    plt.show()



.. image:: output_93_0.png


AGE VS OVERALL RATING COMPARISON

.. code:: ipython3

    plt.figure(1 , figsize = (15 , 6))
    sns.boxplot(df_fifa["Age"], df_fifa["Overall"])
    plt.title("Age vs Overall rating Comparison")
    plt.show()



.. image:: output_95_0.png


AGE VS STAMINA COMPARISON

.. code:: ipython3

    plt.figure(1 , figsize = (15 , 9))
    sns.boxplot(x = "Age", y = "Stamina", data = df_fifa)
    plt.title("Age vs Stamina Comparison")
    plt.show()



.. image:: output_97_0.png


AGE VS SPRINT SPEED COMPARISON

.. code:: ipython3

    plt.figure(1 , figsize = (15 , 9))
    sns.boxplot(x = "Age", y = "SprintSpeed", data = df_fifa)
    plt.title("Age vs Sprint Speed Comparison")
    plt.show()



.. image:: output_99_0.png


AGE VS REACTION COMPARISON

.. code:: ipython3

    plt.figure(1 , figsize = (15 , 9))
    sns.boxplot(x = "Age", y = "Reactions", data = df_fifa)
    plt.title("Age vs Reactions Comparison")
    plt.show()



.. image:: output_101_0.png


DRIBBLING VS FINISHING COMPARISON

.. code:: ipython3

    plt.figure(1 , figsize = (25 , 9))
    sns.boxplot(x = "Dribbling", y = "Finishing", data = df_fifa)
    plt.title("Dribbling vs Finishing Comparison")
    plt.show()



.. image:: output_103_0.png


AGE VS FINISHING COMPARISON

.. code:: ipython3

    plt.figure(1 , figsize = (15 , 9))
    sns.boxplot(x = "Age", y = "Finishing", data = df_fifa)
    plt.title("Age vs Finishing Comparison")
    plt.show()



.. image:: output_105_0.png


COMPARING FEATURES WITH RESPECT TO ACCELERATION

.. code:: ipython3

    def make_scatter(df_fifa):
        feats = ("Agility", "Balance", "Dribbling", "SprintSpeed")
        
        for index, feat in enumerate(feats):
            plt.subplot(len(feats)/4+1, 4, index+1)
            ax = sns.regplot(x = 'Acceleration', y = feat, data = df_fifa)
    
    plt.figure(figsize = (20, 20))
    plt.subplots_adjust(hspace = 0.4)
    
    make_scatter(df_fifa)
    plt.show()



.. image:: output_107_0.png


COUNTRY WITH MOST PLAYERS

.. code:: ipython3

    print("Total number of countries : {0}".format(df_fifa["Nationality"].nunique()))
    print(df_fifa["Nationality"].value_counts().head(10))
    


.. parsed-literal::

    Total number of countries : 164
    England        1662
    Germany        1198
    Spain          1072
    Argentina       937
    France          914
    Brazil          827
    Italy           702
    Colombia        618
    Japan           478
    Netherlands     453
    Name: Nationality, dtype: int64
    

COUNTPLOT DISTRIBUTION

.. code:: ipython3

    plt.figure(1, figsize = (20 , 7))
    countries = []
    c = counter(df_fifa["Nationality"]).most_common()[:11]
    for n in range(11) : countries.append(c[n][0])
    sns.countplot(x  = "Nationality", data = df_fifa[df_fifa["Nationality"].isin(countries)],
                  order  = df_fifa[df_fifa["Nationality"].isin(countries)]["Nationality"].value_counts().index, 
                  palette = "rocket") 
    plt.xticks(rotation = 90)
    plt.title("Most Players Belong To" )
    plt.show()



.. image:: output_111_0.png


PIE CHART DISTRIBUTION

.. code:: ipython3

    countries=df_fifa["Nationality"].value_counts()
    index=countries.index
    con=pd.DataFrame({"Country":index,"Count":countries})
    con=con["England":"Netherlands"]
    plt.pie(con["Count"],labels=con["Country"],wedgeprops = {"linewidth": 5},autopct='%1.2f%%')
    plt.title("Distribution of players in top 10 countries")
    plt.tight_layout()
    plt.show()



.. image:: output_113_0.png


COMPARISON - FC BARCELONA, REAL MADRID, LIVERPOOL AND MANCHESTER CITY
---------------------------------------------------------------------

FC BARCELONA
============

.. code:: ipython3

    plt.figure(1, figsize = (15, 10))
    img = mpimg.imread("Barcelonalogo.jpg") 
    plt.imshow(img)
    plt.show()



.. image:: output_116_0.png


FULL SQUAD LIST OF FC BARCELONA

.. code:: ipython3

    df_fifa[df_fifa["Club"] == "FC Barcelona"][["Name", "Position", "Overall", "Age", "Wage", "Nationality"]]




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Position</th>
          <th>Overall</th>
          <th>Age</th>
          <th>Wage</th>
          <th>Nationality</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>L. Messi</td>
          <td>RF</td>
          <td>94</td>
          <td>31</td>
          <td>€565K</td>
          <td>Argentina</td>
        </tr>
        <tr>
          <th>7</th>
          <td>L. Suárez</td>
          <td>RS</td>
          <td>91</td>
          <td>31</td>
          <td>€455K</td>
          <td>Uruguay</td>
        </tr>
        <tr>
          <th>18</th>
          <td>M. ter Stegen</td>
          <td>GK</td>
          <td>89</td>
          <td>26</td>
          <td>€240K</td>
          <td>Germany</td>
        </tr>
        <tr>
          <th>20</th>
          <td>Sergio Busquets</td>
          <td>CDM</td>
          <td>89</td>
          <td>29</td>
          <td>€315K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>32</th>
          <td>Coutinho</td>
          <td>LW</td>
          <td>88</td>
          <td>26</td>
          <td>€340K</td>
          <td>Brazil</td>
        </tr>
        <tr>
          <th>42</th>
          <td>S. Umtiti</td>
          <td>CB</td>
          <td>87</td>
          <td>24</td>
          <td>€205K</td>
          <td>France</td>
        </tr>
        <tr>
          <th>49</th>
          <td>Jordi Alba</td>
          <td>LB</td>
          <td>87</td>
          <td>29</td>
          <td>€250K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>53</th>
          <td>I. Rakitić</td>
          <td>RCM</td>
          <td>87</td>
          <td>30</td>
          <td>€260K</td>
          <td>Croatia</td>
        </tr>
        <tr>
          <th>54</th>
          <td>Piqué</td>
          <td>RCB</td>
          <td>87</td>
          <td>31</td>
          <td>€240K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>96</th>
          <td>A. Vidal</td>
          <td>CAM</td>
          <td>85</td>
          <td>31</td>
          <td>€205K</td>
          <td>Chile</td>
        </tr>
        <tr>
          <th>155</th>
          <td>O. Dembélé</td>
          <td>RW</td>
          <td>83</td>
          <td>21</td>
          <td>€155K</td>
          <td>France</td>
        </tr>
        <tr>
          <th>192</th>
          <td>Sergi Roberto</td>
          <td>RB</td>
          <td>83</td>
          <td>26</td>
          <td>€170K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>228</th>
          <td>Arthur</td>
          <td>LCM</td>
          <td>82</td>
          <td>21</td>
          <td>€125K</td>
          <td>Brazil</td>
        </tr>
        <tr>
          <th>236</th>
          <td>Malcom</td>
          <td>RW</td>
          <td>82</td>
          <td>21</td>
          <td>€140K</td>
          <td>Brazil</td>
        </tr>
        <tr>
          <th>239</th>
          <td>C. Lenglet</td>
          <td>LCB</td>
          <td>82</td>
          <td>23</td>
          <td>€135K</td>
          <td>France</td>
        </tr>
        <tr>
          <th>263</th>
          <td>Rafinha</td>
          <td>CAM</td>
          <td>82</td>
          <td>25</td>
          <td>€165K</td>
          <td>Brazil</td>
        </tr>
        <tr>
          <th>266</th>
          <td>J. Cillessen</td>
          <td>GK</td>
          <td>82</td>
          <td>29</td>
          <td>€135K</td>
          <td>Netherlands</td>
        </tr>
        <tr>
          <th>324</th>
          <td>Nélson Semedo</td>
          <td>RB</td>
          <td>81</td>
          <td>24</td>
          <td>€125K</td>
          <td>Portugal</td>
        </tr>
        <tr>
          <th>613</th>
          <td>Denis Suárez</td>
          <td>CM</td>
          <td>79</td>
          <td>24</td>
          <td>€120K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>1007</th>
          <td>Munir</td>
          <td>ST</td>
          <td>77</td>
          <td>22</td>
          <td>€115K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>1037</th>
          <td>T. Vermaelen</td>
          <td>CB</td>
          <td>77</td>
          <td>32</td>
          <td>€110K</td>
          <td>Belgium</td>
        </tr>
        <tr>
          <th>3118</th>
          <td>Sergi Samper</td>
          <td>CDM</td>
          <td>73</td>
          <td>23</td>
          <td>€69K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>3684</th>
          <td>Aleñá</td>
          <td>CM</td>
          <td>72</td>
          <td>20</td>
          <td>€58K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>6000</th>
          <td>M. Wagué</td>
          <td>RB</td>
          <td>69</td>
          <td>19</td>
          <td>€20K</td>
          <td>Senegal</td>
        </tr>
        <tr>
          <th>6102</th>
          <td>Riqui Puig</td>
          <td>CM</td>
          <td>69</td>
          <td>18</td>
          <td>€24K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>8284</th>
          <td>Oriol Busquets</td>
          <td>CDM</td>
          <td>67</td>
          <td>19</td>
          <td>€14K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>8289</th>
          <td>Abel Ruiz</td>
          <td>ST</td>
          <td>67</td>
          <td>18</td>
          <td>€21K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>8857</th>
          <td>Miranda</td>
          <td>LB</td>
          <td>66</td>
          <td>18</td>
          <td>€12K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>10526</th>
          <td>Chumi</td>
          <td>CB</td>
          <td>65</td>
          <td>19</td>
          <td>€11K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>10777</th>
          <td>Jorge Cuenca</td>
          <td>CB</td>
          <td>65</td>
          <td>18</td>
          <td>€11K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>11300</th>
          <td>Guillem Jaime</td>
          <td>RW</td>
          <td>64</td>
          <td>19</td>
          <td>€13K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>12502</th>
          <td>Ezkieta</td>
          <td>GK</td>
          <td>63</td>
          <td>21</td>
          <td>€10K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>14286</th>
          <td>Iñaki Peña</td>
          <td>GK</td>
          <td>61</td>
          <td>19</td>
          <td>€4K</td>
          <td>Spain</td>
        </tr>
      </tbody>
    </table>
    </div>



THE BEST PLAYER OF FC BARCELONA
===============================

LIONEL MESSI HAS BEEN RANKED AT THE TOP OF FIFA19 RATINGS

HE IS ALSO THE BEST PLAYER OF FC BARCELONA

.. code:: ipython3

    plt.figure(1, figsize = (15, 10))
    img = mpimg.imread("Messi.jpg") 
    plt.imshow(img)
    plt.show()



.. image:: output_122_0.png


REAL MADRID
===========

.. code:: ipython3

    plt.figure(1, figsize = (15, 20))
    img = mpimg.imread("rmlogo.png") 
    plt.imshow(img)
    plt.show()



.. image:: output_124_0.png


FULL SQUAD LIST OF REAL MADRID

.. code:: ipython3

    df_fifa[df_fifa["Club"] == "Real Madrid"][["Name", "Position", "Overall", "Age", "Wage", "Nationality"]]




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Position</th>
          <th>Overall</th>
          <th>Age</th>
          <th>Wage</th>
          <th>Nationality</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>6</th>
          <td>L. Modrić</td>
          <td>RCM</td>
          <td>91</td>
          <td>32</td>
          <td>€420K</td>
          <td>Croatia</td>
        </tr>
        <tr>
          <th>8</th>
          <td>Sergio Ramos</td>
          <td>RCB</td>
          <td>91</td>
          <td>32</td>
          <td>€380K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>11</th>
          <td>T. Kroos</td>
          <td>LCM</td>
          <td>90</td>
          <td>28</td>
          <td>€355K</td>
          <td>Germany</td>
        </tr>
        <tr>
          <th>19</th>
          <td>T. Courtois</td>
          <td>GK</td>
          <td>89</td>
          <td>26</td>
          <td>€240K</td>
          <td>Belgium</td>
        </tr>
        <tr>
          <th>27</th>
          <td>Casemiro</td>
          <td>CDM</td>
          <td>88</td>
          <td>26</td>
          <td>€285K</td>
          <td>Brazil</td>
        </tr>
        <tr>
          <th>30</th>
          <td>Isco</td>
          <td>LW</td>
          <td>88</td>
          <td>26</td>
          <td>€315K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>35</th>
          <td>Marcelo</td>
          <td>LB</td>
          <td>88</td>
          <td>30</td>
          <td>€285K</td>
          <td>Brazil</td>
        </tr>
        <tr>
          <th>36</th>
          <td>G. Bale</td>
          <td>ST</td>
          <td>88</td>
          <td>28</td>
          <td>€355K</td>
          <td>Wales</td>
        </tr>
        <tr>
          <th>46</th>
          <td>K. Navas</td>
          <td>GK</td>
          <td>87</td>
          <td>31</td>
          <td>€195K</td>
          <td>Costa Rica</td>
        </tr>
        <tr>
          <th>62</th>
          <td>R. Varane</td>
          <td>RCB</td>
          <td>86</td>
          <td>25</td>
          <td>€210K</td>
          <td>France</td>
        </tr>
        <tr>
          <th>79</th>
          <td>Marco Asensio</td>
          <td>RW</td>
          <td>85</td>
          <td>22</td>
          <td>€215K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>105</th>
          <td>K. Benzema</td>
          <td>ST</td>
          <td>85</td>
          <td>30</td>
          <td>€240K</td>
          <td>France</td>
        </tr>
        <tr>
          <th>123</th>
          <td>Carvajal</td>
          <td>RB</td>
          <td>84</td>
          <td>26</td>
          <td>€185K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>172</th>
          <td>Lucas Vázquez</td>
          <td>RW</td>
          <td>83</td>
          <td>27</td>
          <td>€205K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>188</th>
          <td>Nacho Fernández</td>
          <td>CB</td>
          <td>83</td>
          <td>28</td>
          <td>€180K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>328</th>
          <td>Dani Ceballos</td>
          <td>LCM</td>
          <td>81</td>
          <td>21</td>
          <td>€120K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>417</th>
          <td>Odriozola</td>
          <td>RB</td>
          <td>80</td>
          <td>22</td>
          <td>€115K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>430</th>
          <td>Mariano</td>
          <td>ST</td>
          <td>80</td>
          <td>24</td>
          <td>€140K</td>
          <td>Dominican Republic</td>
        </tr>
        <tr>
          <th>573</th>
          <td>Marcos Llorente</td>
          <td>CDM</td>
          <td>79</td>
          <td>23</td>
          <td>€110K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>697</th>
          <td>Kiko Casilla</td>
          <td>GK</td>
          <td>79</td>
          <td>31</td>
          <td>€105K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>754</th>
          <td>Vallejo</td>
          <td>CB</td>
          <td>78</td>
          <td>21</td>
          <td>€81K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>1143</th>
          <td>Vinícius Júnior</td>
          <td>LW</td>
          <td>77</td>
          <td>17</td>
          <td>€66K</td>
          <td>Brazil</td>
        </tr>
        <tr>
          <th>2513</th>
          <td>F. Valverde</td>
          <td>CM</td>
          <td>74</td>
          <td>19</td>
          <td>€46K</td>
          <td>Uruguay</td>
        </tr>
        <tr>
          <th>6724</th>
          <td>Reguilón</td>
          <td>LB</td>
          <td>68</td>
          <td>21</td>
          <td>€28K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>8732</th>
          <td>Javi Sánchez</td>
          <td>CB</td>
          <td>67</td>
          <td>21</td>
          <td>€24K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>9141</th>
          <td>Cristo González</td>
          <td>ST</td>
          <td>66</td>
          <td>20</td>
          <td>€26K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>10178</th>
          <td>F. Feuillassier</td>
          <td>LW</td>
          <td>65</td>
          <td>20</td>
          <td>€23K</td>
          <td>Argentina</td>
        </tr>
        <tr>
          <th>10269</th>
          <td>Fidalgo</td>
          <td>CM</td>
          <td>65</td>
          <td>21</td>
          <td>€20K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>11163</th>
          <td>Sergio López</td>
          <td>RB</td>
          <td>64</td>
          <td>19</td>
          <td>€9K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>11327</th>
          <td>Fran García</td>
          <td>LB</td>
          <td>64</td>
          <td>18</td>
          <td>€9K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>11877</th>
          <td>Manu Hernando</td>
          <td>CB</td>
          <td>64</td>
          <td>19</td>
          <td>€9K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>12504</th>
          <td>Dani Gómez</td>
          <td>ST</td>
          <td>63</td>
          <td>19</td>
          <td>€12K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>13687</th>
          <td>L. Zidane</td>
          <td>GK</td>
          <td>62</td>
          <td>20</td>
          <td>€9K</td>
          <td>France</td>
        </tr>
      </tbody>
    </table>
    </div>



BEST PLAYER OF REAL MADRID
==========================

LUKA MODRIC IS THE HIGHEST RATED REAL MADRID PLAYER IN FIFA19

.. code:: ipython3

    plt.figure(1, figsize = (15, 20))
    img = mpimg.imread("modric.jpg") 
    plt.imshow(img)
    plt.show()



.. image:: output_129_0.png


LIVERPOOL FOOTBALL CLUB
=======================

.. code:: ipython3

    plt.figure(1, figsize = (15, 20))
    img = mpimg.imread("liverpoollogo.jpg") 
    plt.imshow(img)
    plt.show()



.. image:: output_131_0.png


FULL SQUAD LIST OF LIVERPOOL

.. code:: ipython3

    df_fifa[df_fifa["Club"] == "Liverpool"][["Name", "Position", "Overall", "Age", "Wage", "Nationality"]]




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Position</th>
          <th>Overall</th>
          <th>Age</th>
          <th>Wage</th>
          <th>Nationality</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>26</th>
          <td>M. Salah</td>
          <td>RM</td>
          <td>88</td>
          <td>26</td>
          <td>€255K</td>
          <td>Egypt</td>
        </tr>
        <tr>
          <th>58</th>
          <td>S. Mané</td>
          <td>LM</td>
          <td>86</td>
          <td>26</td>
          <td>€195K</td>
          <td>Senegal</td>
        </tr>
        <tr>
          <th>59</th>
          <td>V. van Dijk</td>
          <td>LCB</td>
          <td>86</td>
          <td>26</td>
          <td>€165K</td>
          <td>Netherlands</td>
        </tr>
        <tr>
          <th>61</th>
          <td>Roberto Firmino</td>
          <td>CAM</td>
          <td>86</td>
          <td>26</td>
          <td>€195K</td>
          <td>Brazil</td>
        </tr>
        <tr>
          <th>81</th>
          <td>Alisson</td>
          <td>GK</td>
          <td>85</td>
          <td>25</td>
          <td>€115K</td>
          <td>Brazil</td>
        </tr>
        <tr>
          <th>118</th>
          <td>Fabinho</td>
          <td>CDM</td>
          <td>84</td>
          <td>24</td>
          <td>€120K</td>
          <td>Brazil</td>
        </tr>
        <tr>
          <th>161</th>
          <td>N. Keïta</td>
          <td>CM</td>
          <td>83</td>
          <td>23</td>
          <td>€120K</td>
          <td>Guinea</td>
        </tr>
        <tr>
          <th>241</th>
          <td>A. Robertson</td>
          <td>LB</td>
          <td>82</td>
          <td>24</td>
          <td>€98K</td>
          <td>Scotland</td>
        </tr>
        <tr>
          <th>296</th>
          <td>J. Henderson</td>
          <td>RCM</td>
          <td>82</td>
          <td>28</td>
          <td>€125K</td>
          <td>England</td>
        </tr>
        <tr>
          <th>302</th>
          <td>G. Wijnaldum</td>
          <td>CAM</td>
          <td>82</td>
          <td>27</td>
          <td>€130K</td>
          <td>Netherlands</td>
        </tr>
        <tr>
          <th>368</th>
          <td>D. Lovren</td>
          <td>RCB</td>
          <td>81</td>
          <td>28</td>
          <td>€115K</td>
          <td>Croatia</td>
        </tr>
        <tr>
          <th>370</th>
          <td>X. Shaqiri</td>
          <td>CAM</td>
          <td>81</td>
          <td>26</td>
          <td>€130K</td>
          <td>Switzerland</td>
        </tr>
        <tr>
          <th>409</th>
          <td>J. Milner</td>
          <td>CM</td>
          <td>81</td>
          <td>32</td>
          <td>€120K</td>
          <td>England</td>
        </tr>
        <tr>
          <th>481</th>
          <td>A. Oxlade-Chamberlain</td>
          <td>CM</td>
          <td>80</td>
          <td>24</td>
          <td>€94K</td>
          <td>England</td>
        </tr>
        <tr>
          <th>483</th>
          <td>J. Matip</td>
          <td>CB</td>
          <td>80</td>
          <td>26</td>
          <td>€99K</td>
          <td>Cameroon</td>
        </tr>
        <tr>
          <th>515</th>
          <td>A. Lallana</td>
          <td>CM</td>
          <td>80</td>
          <td>30</td>
          <td>€110K</td>
          <td>England</td>
        </tr>
        <tr>
          <th>529</th>
          <td>D. Sturridge</td>
          <td>ST</td>
          <td>80</td>
          <td>28</td>
          <td>€125K</td>
          <td>England</td>
        </tr>
        <tr>
          <th>665</th>
          <td>N. Clyne</td>
          <td>RB</td>
          <td>79</td>
          <td>27</td>
          <td>€94K</td>
          <td>England</td>
        </tr>
        <tr>
          <th>703</th>
          <td>S. Mignolet</td>
          <td>GK</td>
          <td>79</td>
          <td>30</td>
          <td>€76K</td>
          <td>Belgium</td>
        </tr>
        <tr>
          <th>735</th>
          <td>T. Alexander-Arnold</td>
          <td>RB</td>
          <td>78</td>
          <td>19</td>
          <td>€36K</td>
          <td>England</td>
        </tr>
        <tr>
          <th>755</th>
          <td>J. Gomez</td>
          <td>CB</td>
          <td>78</td>
          <td>21</td>
          <td>€61K</td>
          <td>England</td>
        </tr>
        <tr>
          <th>1063</th>
          <td>D. Origi</td>
          <td>ST</td>
          <td>77</td>
          <td>23</td>
          <td>€83K</td>
          <td>Belgium</td>
        </tr>
        <tr>
          <th>1194</th>
          <td>Alberto Moreno</td>
          <td>LB</td>
          <td>77</td>
          <td>25</td>
          <td>€76K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>2405</th>
          <td>L. Marković</td>
          <td>RM</td>
          <td>74</td>
          <td>24</td>
          <td>€62K</td>
          <td>Serbia</td>
        </tr>
        <tr>
          <th>4763</th>
          <td>D. Solanke</td>
          <td>ST</td>
          <td>70</td>
          <td>20</td>
          <td>€37K</td>
          <td>England</td>
        </tr>
        <tr>
          <th>8853</th>
          <td>Pedro Chirivella</td>
          <td>CM</td>
          <td>66</td>
          <td>21</td>
          <td>€17K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>13503</th>
          <td>R. Brewster</td>
          <td>ST</td>
          <td>62</td>
          <td>18</td>
          <td>€8K</td>
          <td>England</td>
        </tr>
        <tr>
          <th>13961</th>
          <td>C. Jones</td>
          <td>CM</td>
          <td>61</td>
          <td>17</td>
          <td>€7K</td>
          <td>England</td>
        </tr>
        <tr>
          <th>14036</th>
          <td>N. Phillips</td>
          <td>CB</td>
          <td>61</td>
          <td>21</td>
          <td>€9K</td>
          <td>England</td>
        </tr>
        <tr>
          <th>14252</th>
          <td>Rafael Camacho</td>
          <td>CAM</td>
          <td>61</td>
          <td>18</td>
          <td>€7K</td>
          <td>Portugal</td>
        </tr>
        <tr>
          <th>14674</th>
          <td>B. Adekanye</td>
          <td>RW</td>
          <td>60</td>
          <td>19</td>
          <td>€7K</td>
          <td>Netherlands</td>
        </tr>
        <tr>
          <th>15378</th>
          <td>K. Grabara</td>
          <td>GK</td>
          <td>59</td>
          <td>19</td>
          <td>€3K</td>
          <td>Poland</td>
        </tr>
        <tr>
          <th>15627</th>
          <td>M. Virtue</td>
          <td>CDM</td>
          <td>59</td>
          <td>21</td>
          <td>€8K</td>
          <td>England</td>
        </tr>
      </tbody>
    </table>
    </div>



BEST PLAYER OF LIVERPOOL
========================

M. SALAH IS HIGHEST RATED LIVERPOOL PLAYER IN FIFA19

.. code:: ipython3

    plt.figure(1, figsize = (15, 20))
    img = mpimg.imread("salah.jpg") 
    plt.imshow(img)
    plt.show()



.. image:: output_136_0.png


MANCHESTER CITY
===============

.. code:: ipython3

    plt.figure(1, figsize = (15, 20))
    img = mpimg.imread("mancitylogo.jpg") 
    plt.imshow(img)
    plt.show()



.. image:: output_138_0.png


FULL SQUAD LIST OF MANCHESTER CITY

.. code:: ipython3

    df_fifa[df_fifa["Club"] == "Manchester City"][["Name", "Position", "Overall", "Age", "Wage", "Nationality"]]




.. raw:: html

    <div>
    <style>
        .dataframe thead tr:only-child th {
            text-align: right;
        }
    
        .dataframe thead th {
            text-align: left;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Name</th>
          <th>Position</th>
          <th>Overall</th>
          <th>Age</th>
          <th>Wage</th>
          <th>Nationality</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>4</th>
          <td>K. De Bruyne</td>
          <td>RCM</td>
          <td>91</td>
          <td>27</td>
          <td>€355K</td>
          <td>Belgium</td>
        </tr>
        <tr>
          <th>13</th>
          <td>David Silva</td>
          <td>LCM</td>
          <td>90</td>
          <td>32</td>
          <td>€285K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>23</th>
          <td>S. Agüero</td>
          <td>ST</td>
          <td>89</td>
          <td>30</td>
          <td>€300K</td>
          <td>Argentina</td>
        </tr>
        <tr>
          <th>55</th>
          <td>L. Sané</td>
          <td>LW</td>
          <td>86</td>
          <td>22</td>
          <td>€195K</td>
          <td>Germany</td>
        </tr>
        <tr>
          <th>56</th>
          <td>Bernardo Silva</td>
          <td>RW</td>
          <td>86</td>
          <td>23</td>
          <td>€180K</td>
          <td>Portugal</td>
        </tr>
        <tr>
          <th>57</th>
          <td>Ederson</td>
          <td>GK</td>
          <td>86</td>
          <td>24</td>
          <td>€125K</td>
          <td>Brazil</td>
        </tr>
        <tr>
          <th>60</th>
          <td>R. Sterling</td>
          <td>RW</td>
          <td>86</td>
          <td>23</td>
          <td>€195K</td>
          <td>England</td>
        </tr>
        <tr>
          <th>75</th>
          <td>Fernandinho</td>
          <td>CDM</td>
          <td>86</td>
          <td>33</td>
          <td>€185K</td>
          <td>Brazil</td>
        </tr>
        <tr>
          <th>84</th>
          <td>R. Mahrez</td>
          <td>RW</td>
          <td>85</td>
          <td>27</td>
          <td>€205K</td>
          <td>Algeria</td>
        </tr>
        <tr>
          <th>89</th>
          <td>N. Otamendi</td>
          <td>CB</td>
          <td>85</td>
          <td>30</td>
          <td>€170K</td>
          <td>Argentina</td>
        </tr>
        <tr>
          <th>107</th>
          <td>V. Kompany</td>
          <td>CB</td>
          <td>85</td>
          <td>32</td>
          <td>€170K</td>
          <td>Belgium</td>
        </tr>
        <tr>
          <th>113</th>
          <td>A. Laporte</td>
          <td>LCB</td>
          <td>84</td>
          <td>24</td>
          <td>€135K</td>
          <td>France</td>
        </tr>
        <tr>
          <th>135</th>
          <td>K. Walker</td>
          <td>RB</td>
          <td>84</td>
          <td>28</td>
          <td>€165K</td>
          <td>England</td>
        </tr>
        <tr>
          <th>136</th>
          <td>I. Gündoğan</td>
          <td>CM</td>
          <td>84</td>
          <td>27</td>
          <td>€175K</td>
          <td>Germany</td>
        </tr>
        <tr>
          <th>156</th>
          <td>Gabriel Jesus</td>
          <td>ST</td>
          <td>83</td>
          <td>21</td>
          <td>€130K</td>
          <td>Brazil</td>
        </tr>
        <tr>
          <th>182</th>
          <td>J. Stones</td>
          <td>RCB</td>
          <td>83</td>
          <td>24</td>
          <td>€125K</td>
          <td>England</td>
        </tr>
        <tr>
          <th>352</th>
          <td>B. Mendy</td>
          <td>LB</td>
          <td>81</td>
          <td>23</td>
          <td>€105K</td>
          <td>France</td>
        </tr>
        <tr>
          <th>514</th>
          <td>F. Delph</td>
          <td>LB</td>
          <td>80</td>
          <td>28</td>
          <td>€120K</td>
          <td>England</td>
        </tr>
        <tr>
          <th>645</th>
          <td>Danilo</td>
          <td>RB</td>
          <td>79</td>
          <td>26</td>
          <td>€110K</td>
          <td>Brazil</td>
        </tr>
        <tr>
          <th>871</th>
          <td>C. Bravo</td>
          <td>GK</td>
          <td>78</td>
          <td>35</td>
          <td>€50K</td>
          <td>Chile</td>
        </tr>
        <tr>
          <th>1304</th>
          <td>E. Mangala</td>
          <td>CB</td>
          <td>76</td>
          <td>27</td>
          <td>€84K</td>
          <td>France</td>
        </tr>
        <tr>
          <th>2903</th>
          <td>P. Foden</td>
          <td>CAM</td>
          <td>73</td>
          <td>18</td>
          <td>€36K</td>
          <td>England</td>
        </tr>
        <tr>
          <th>4652</th>
          <td>O. Zinchenko</td>
          <td>LB</td>
          <td>71</td>
          <td>21</td>
          <td>€38K</td>
          <td>Ukraine</td>
        </tr>
        <tr>
          <th>6316</th>
          <td>P. Sandler</td>
          <td>CB</td>
          <td>69</td>
          <td>21</td>
          <td>€28K</td>
          <td>Netherlands</td>
        </tr>
        <tr>
          <th>6559</th>
          <td>Brahim Díaz</td>
          <td>LW</td>
          <td>69</td>
          <td>18</td>
          <td>€24K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>8966</th>
          <td>C. Gomes</td>
          <td>CDM</td>
          <td>66</td>
          <td>17</td>
          <td>€10K</td>
          <td>France</td>
        </tr>
        <tr>
          <th>13211</th>
          <td>Eric García</td>
          <td>CB</td>
          <td>62</td>
          <td>17</td>
          <td>€6K</td>
          <td>Spain</td>
        </tr>
        <tr>
          <th>13814</th>
          <td>C. Humphreys-Grant</td>
          <td>CB</td>
          <td>62</td>
          <td>19</td>
          <td>€6K</td>
          <td>England</td>
        </tr>
        <tr>
          <th>14197</th>
          <td>L. Bolton</td>
          <td>RM</td>
          <td>61</td>
          <td>18</td>
          <td>€7K</td>
          <td>England</td>
        </tr>
        <tr>
          <th>14511</th>
          <td>A. Muric</td>
          <td>GK</td>
          <td>61</td>
          <td>19</td>
          <td>€3K</td>
          <td>Montenegro</td>
        </tr>
        <tr>
          <th>15210</th>
          <td>B. Garré</td>
          <td>LW</td>
          <td>60</td>
          <td>17</td>
          <td>€7K</td>
          <td>Argentina</td>
        </tr>
        <tr>
          <th>16403</th>
          <td>T. Dele-Bashiru</td>
          <td>CM</td>
          <td>57</td>
          <td>18</td>
          <td>€6K</td>
          <td>England</td>
        </tr>
        <tr>
          <th>17451</th>
          <td>D. Grimshaw</td>
          <td>GK</td>
          <td>54</td>
          <td>20</td>
          <td>€6K</td>
          <td>England</td>
        </tr>
      </tbody>
    </table>
    </div>



BEST PLAYER OF MANCHESTER CITY
==============================

KEVIN DE BRUYNE IS THE HIGHEST RATED MANCHESTER CITY PLAYER IN FIFA19

.. code:: ipython3

    plt.figure(1, figsize = (15, 20))
    img = mpimg.imread("kevin.jpg") 
    plt.imshow(img)
    plt.show()



.. image:: output_143_0.png


DEFINING NEW VARIABLE NAME FOR THE CLUBS

.. code:: ipython3

    barca = df_fifa[df_fifa["Club"] == "FC Barcelona"]
    madrid = df_fifa[df_fifa["Club"] == "Real Madrid"]
    liverpool = df_fifa[df_fifa["Club"] == "Liverpool"]
    mancity = df_fifa[df_fifa["Club"] == "Manchester City"]

NUMBER OF FC BARCELONA PLAYERS AVAILABLE FOR EACH POSITION

.. code:: ipython3

    barca["Position"].value_counts()




.. parsed-literal::

    CB     4
    GK     4
    CDM    3
    CM     3
    RW     3
    RB     3
    LB     2
    ST     2
    CAM    2
    RCB    1
    LCM    1
    RCM    1
    LCB    1
    RF     1
    RS     1
    LW     1
    Name: Position, dtype: int64



NUMBER OF REAL MADRID PLAYERS AVAILABLE FOR EACH POSITION

.. code:: ipython3

    madrid["Position"].value_counts()




.. parsed-literal::

    ST     5
    GK     4
    CB     4
    LW     3
    LB     3
    RB     3
    CM     2
    RCB    2
    RW     2
    CDM    2
    LCM    2
    RCM    1
    Name: Position, dtype: int64



NUMBER OF LIVERPOOL PLAYERS AVAILABLE FOR EACH POSITION

.. code:: ipython3

    liverpool["Position"].value_counts()




.. parsed-literal::

    CM     6
    ST     4
    CAM    4
    CB     3
    GK     3
    LB     2
    CDM    2
    RM     2
    RB     2
    RCB    1
    LCB    1
    RCM    1
    RW     1
    LM     1
    Name: Position, dtype: int64



NUMBER OF MANCHESTER CITY PLAYERS AVAILABLE FOR EACH POSITION

.. code:: ipython3

    mancity["Position"].value_counts()




.. parsed-literal::

    CB     6
    GK     4
    LB     3
    RW     3
    LW     3
    CM     2
    CDM    2
    ST     2
    RB     2
    RM     1
    RCB    1
    LCB    1
    LCM    1
    RCM    1
    CAM    1
    Name: Position, dtype: int64



DISTPLOT : AGE OF PLAYERS

.. code:: ipython3

    plt.figure(1, figsize = (15, 6))
    sns.distplot(barca["Age"], color = "blue")
    sns.distplot(madrid["Age"], color = "black")
    sns.distplot(liverpool["Age"], color = "red")
    sns.distplot(mancity["Age"], color = "white")
    plt.title("Comparison of distribution of Age between Top Club players")
    plt.tight_layout()
    plt.show()



.. image:: output_155_0.png


DISTPLOT : PLAYER RATING

.. code:: ipython3

    plt.figure(1, figsize = (15, 6))
    sns.distplot(barca["Overall"], color = "blue")
    sns.distplot(madrid["Overall"], color = "black")
    sns.distplot(liverpool["Overall"], color = "red")
    sns.distplot(mancity["Overall"], color = "white")
    plt.title("Comparison of distribution of Player Ratings between Top Club players")
    plt.tight_layout()
    plt.show()



.. image:: output_157_0.png


COMPARING PLAYER VALUE DISTRIBUTION AMONG CLUBS

.. code:: ipython3

    plt.figure(1, figsize = (15, 6))
    sns.distplot(barca["Value_num"], color = "blue")
    sns.distplot(madrid["Value_num"], color = "black")
    sns.distplot(liverpool["Value_num"], color = "red")
    sns.distplot(mancity["Value_num"], color = "white")
    plt.title("Comparison of Player Value between in Top Clubs")
    plt.tight_layout()
    plt.show()



.. image:: output_159_0.png


COMPARING PLAYER WAGE DISTRIBUTION

.. code:: ipython3

    plt.figure(1, figsize = (15, 6))
    sns.distplot(barca["Wage_num"], color = "blue")
    sns.distplot(madrid["Wage_num"], color = "black")
    sns.distplot(liverpool["Wage_num"], color = "red")
    sns.distplot(mancity["Wage_num"], color = "white")
    plt.title("Comparison of Player Wages between Top Club")
    plt.tight_layout()
    plt.show()



.. image:: output_161_0.png


COMPARING PLAYER POTENTIAL

.. code:: ipython3

    plt.figure(1, figsize = (15, 6))
    sns.distplot(barca["Potential"], color = "blue")
    sns.distplot(madrid["Potential"], color = "black")
    sns.distplot(liverpool["Potential"], color = "red")
    sns.distplot(mancity["Potential"], color = "white")
    plt.title("Distribution of Player Potential between Top Club")
    plt.tight_layout()
    plt.show()



.. image:: output_163_0.png


COMPARING PLAYERS FINISHING

BETTER FINISHING LEADS TO MORE GOALS SCORED

.. code:: ipython3

    plt.figure(1, figsize = (15, 6))
    sns.distplot(barca["Finishing"], color = "blue")
    sns.distplot(madrid["Finishing"], color = "black")
    sns.distplot(liverpool["Finishing"], color = "red")
    sns.distplot(mancity["Finishing"], color = "white")
    plt.title("Distribution of Players Finishing capabilities between Top Club")
    plt.tight_layout()
    plt.show()



.. image:: output_166_0.png


COUNTPLOT : PLAYER DISTRIBUTION WITH RESPECT TO COUNTRY

.. code:: ipython3

    plt.figure(1, figsize = (15, 6))
    
    plt.subplot(1, 4, 1)
    sns.countplot(barca["Nationality"], color = "blue")
    plt.xticks(rotation=90)
    plt.title("FC Barcelona")
    
    plt.subplot(1, 4, 2)
    sns.countplot(madrid["Nationality"], color = "black")
    plt.xticks(rotation=90)
    plt.title("Real Madrid")
    
    plt.subplot(1, 4, 3)
    sns.countplot(liverpool["Nationality"], color = "red")
    plt.xticks(rotation=90)
    plt.title("Liverpool")
    
    plt.subplot(1, 4, 4)
    sns.countplot(mancity["Nationality"], color = "green")
    plt.xticks(rotation=90)
    plt.title("Manchester City")
    plt.tight_layout()
    plt.show()



.. image:: output_168_0.png


.. code:: ipython3

    cols = ["Preferred Foot", "International Reputation", 'Skill Moves']
    for col in cols:
        plt.subplot(1, 4, 1)
        sns.countplot(barca[col])
        plt.title("FC Barcelona")
        plt.subplot(1, 4, 2)
        sns.countplot(madrid[col])
        plt.title("Real Madrid")
        plt.subplot(1, 4, 3)
        sns.countplot(liverpool[col])
        plt.title("Liverpool")
        plt.subplot(1, 4, 4)
        sns.countplot(mancity[col])
        plt.title("Manchester City")
        plt.tight_layout()
        plt.show()



.. image:: output_169_0.png



.. image:: output_169_1.png



.. image:: output_169_2.png


BRAIN BEHIND SUCCESSFULL TEAMS
==============================

THE COACH/MANAGERS
------------------

LEFT : PEP GUARDIOLA, CLUBS : FC BARCELONA, FC BAYERN, MANCHESTER CITY

CENTER : ZINEDINE ZIDANE, CLUB : REAL MADRID

RIGHT : JURGEN KLOPP, CLUBS : BORUSSIA DORTMUND, LIVERPOOL

.. code:: ipython3

    plt.figure(1, figsize = (15, 20))
    img = mpimg.imread("managers.jpg") 
    plt.imshow(img)
    plt.show()



.. image:: output_175_0.png


THEY PLAY A VITAL PART IN TEAMS SUCCESS
